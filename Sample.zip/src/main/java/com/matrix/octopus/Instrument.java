package com.matrix.octopus;

import com.matrix.octopus.octo.OctoDefs;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;

/**
 * Created by raviw on 11/2/2017.
 */
public class Instrument {
    public Semaphore mutex_parameter = new Semaphore(1);
    public Semaphore mutex_price = new Semaphore(1);

    public Instrument(String id , String name , String sector) {
        m_instrumentid = id;
        m_instrumentname = name;
        m_sector = sector;
    }
    public String get_instrumentname() {
        return m_instrumentid;
    }
    public String get_instrumentdescription(){return m_instrumentname; }

    public Parameters accquire_parameter() {
        try {
           mutex_parameter.acquire();
            return m_parameters;
        }
        catch (Exception e) {
           Logger.logDebug("error accessing parameter for - " + m_instrumentid , OctoDefs.LOG_LEVEL_DEBUG);
           return null;
        }
    }

    public void release_parameter() {
        mutex_parameter.release();
    }

    public void set_parameter(Parameters parameter) {
        try {
            mutex_parameter.acquire();
            this.m_parameters = parameter;
        }
        catch (Exception e) {
            Logger.logDebug("error accessing parameter for - " + m_instrumentid , OctoDefs.LOG_LEVEL_DEBUG);
        }
        finally {
            mutex_parameter.release();
        }
    }

    public ArrayList<PriceInfo> accquire_pricelist() {
        try {
            mutex_price.acquire();
            return m_pricelist;
        }
        catch (Exception e) {
            Logger.logDebug("error accessing price for - " + m_instrumentid , OctoDefs.LOG_LEVEL_DEBUG);
            return null;
        }
    }

    public void release_priceinfo() {
        mutex_price.release();
    }

    public void set_pricelist(ArrayList<PriceInfo> m_pricelist) {
        try {
            mutex_price.acquire();
            this.m_pricelist = m_pricelist;
        }
        catch (Exception e) {
            Logger.logDebug("error accessing price info setting for - " + m_instrumentid , OctoDefs.LOG_LEVEL_DEBUG);
        }
        finally {
            mutex_price.release();
        }
    }

    public PriceInfo getlatestpriceinfo() {
        PriceInfo pp = null;
        try {
            mutex_price.acquire();
            if (m_pricelist.size() > 0)
                pp = m_pricelist.get(0);
        }
        catch (Exception e) {
            Logger.logDebug("error accessing price info for latest pricing - " + m_instrumentid , OctoDefs.LOG_LEVEL_DEBUG);
        }
        finally {
            mutex_price.release();
        }
        return pp;
    }

    public PriceInfo getoldestpriceinfo() {
        PriceInfo pp = null;
        try {
            mutex_price.acquire();
            if (m_pricelist.size() > 0)
                pp = m_pricelist.get(m_pricelist.size() - 1);
        }
        catch (Exception e) {
            Logger.logDebug("error accessing price info for latest pricing - " + m_instrumentid , OctoDefs.LOG_LEVEL_DEBUG);
        }
        finally {
            mutex_price.release();
        }
        return pp;
    }

    public Double getMean() {
        DescriptiveStatistics stats = new DescriptiveStatistics();
        int size = m_pricelist.size();
        for (int i=0;i<size;i++) {
            stats.addValue(m_pricelist.get(i).getClose());
        }

        return stats.getMean();
    }

    public Double getStd() {
        DescriptiveStatistics stats = new DescriptiveStatistics();
        int size = m_pricelist.size();
        for (int i=0;i<size;i++) {
            stats.addValue(m_pricelist.get(i).getClose());
        }

        return stats.getStandardDeviation();
    }

    public String get_sector() {
        return m_sector;
    }

    private ArrayList<PriceInfo> m_pricelist;
    private Parameters m_parameters = null;
    private String m_instrumentid = "";
    private String m_instrumentname = "";
    private String m_sector = "";
}
