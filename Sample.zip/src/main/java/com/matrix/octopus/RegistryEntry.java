package com.matrix.octopus;

/**
 * Created by raviw on 11/13/2017.
 */
public class RegistryEntry {
    public RegistryEntry(int id , String name , int cpu , String parent) {
        itemid = id;
        itemname = name;
        itemcpu = cpu;
        parentName = parent;
    }

    public int getItemid() {
        return itemid;
    }

    public void setItemid(int itemid) {
        this.itemid = itemid;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public int getItemcpu() {
        return itemcpu;
    }

    public void setItemcpu(int itemcpu) {
        this.itemcpu = itemcpu;
    }

    public String getParentName() { return parentName; }

    private int itemid = 0;
    private String itemname = "";
    private int itemcpu = 0;
    private String parentName = "";
}
