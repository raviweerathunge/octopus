package com.matrix.octopus.blackbox;

import com.matrix.octopus.Instrument;
import com.matrix.octopus.Logger;
import com.matrix.octopus.Parameter;
import com.matrix.octopus.Parameters;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;

import java.util.Map;
import java.util.SortedMap;

/**
 * Created by raviw on 11/20/2017.
 */
public class BBStdDeviation extends OctoBaseBox {

    public void process(SortedMap<String, Instrument> filteredlist) {
        clearFilteredInstruments();

        SortedMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        writeblackboxfile("UPPER/LOWER" + "," + "INSTRUMENT" + "," + "CLOSEPRICE" +  "," + "MEAN" + "," + "STD" + "," + "BOOKVALUE" + "," + "EARNINGS" + "," + "SECTOR");

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);

            Double mean = instemp.getMean();
            Double std = instemp.getStd();

            Double plusstd = mean + 3 * std;
            Double minusstd = mean - 3 * std;

            if (instemp.getlatestpriceinfo() != null) {
                Double closeprice = instemp.getlatestpriceinfo().getClose();
                Parameters params = instemp.accquire_parameter();
                if (closeprice > plusstd || closeprice < minusstd) {

                    Double bookvalue = 0.0;
                    Double earnings = 0.0;

                    if (closeprice > plusstd) {
                        if (params != null) {
                            Parameter parameter = params.getParameter("Book Value Per Share");
                            if (parameter != null)
                                bookvalue = parameter.getAverage();
                            parameter = params.getParameter("Earnings Per Share");
                            if (parameter != null)
                                earnings = parameter.getAverage();
                        }

                        Logger.logDebug("upper " + instrument + " - is : " + closeprice + " Mean:" + mean + " Std " + std + " Book Value: " + bookvalue, OctoDefs.LOG_LEVEL_DEBUG);
                        writeblackboxfile("upper" + "," + instrument + "," + closeprice +  "," + mean + "," + std + "," + bookvalue + "," + earnings + "," + instemp.get_sector());
                    }
                    else {
                        if (params != null) {
                            Parameter parameter = params.getParameter("Book Value Per Share");
                            if (parameter != null)
                                bookvalue = parameter.getAverage();
                            parameter = params.getParameter("Earnings Per Share");
                            if (parameter != null)
                                earnings = parameter.getAverage();
                        }

                        Logger.logDebug("lower " + instrument + " - is : " + closeprice + " Mean:" + mean + " Std " + std + " Book Value: " + bookvalue, OctoDefs.LOG_LEVEL_DEBUG);
                        writeblackboxfile("lower" + "," + instrument + "," + closeprice +  "," + mean + "," + std + "," + bookvalue + "," + earnings + "," + instemp.get_sector());
                        addFilteredInstrument(instrument , instemp);
                    }
                }
                instemp.release_parameter();
            }
        }
    }
}
