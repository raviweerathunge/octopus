package com.matrix.octopus.blackbox;

import com.matrix.octopus.*;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;

import java.util.Map;
import java.util.SortedMap;

/**
 * Created by raviw on 11/22/2017.
 */
public class BBInterestCoverage extends OctoBaseBox {

    public void process(SortedMap<String, Instrument> filteredlist) {
        clearFilteredInstruments();

        SortedMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameter = params.getParameter("Interest Coverage");
                if (parameter != null && parameter.getValidCount() > 5) {
                    if (parameter.getAverage() > 1.5) {
                        Logger.logDebug("printing interest coverage history for " + instrument + " - is : " + parameter.getAverage(), OctoDefs.LOG_LEVEL_DEBUG);
                        writeblackboxfile("printing interest coverage history for " + instrument + " - is : " + parameter.getAverage());
                        addFilteredInstrument(instrument, instemp);
                    }
                    else {
                        Logger.logDebug("filtering out " + instrument + " - is : " + parameter.getAverage(), OctoDefs.LOG_LEVEL_DEBUG);
                        writeblackboxfile("filtering out " + instrument + " - is : " + parameter.getAverage());
                    }
                }
            }
            instemp.release_parameter();
        }
    }
}
