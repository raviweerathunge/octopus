package com.matrix.octopus.blackbox;

import com.matrix.octopus.Instrument;
import com.matrix.octopus.Logger;
import com.matrix.octopus.Parameter;
import com.matrix.octopus.Parameters;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;

import java.util.Map;
import java.util.SortedMap;

/**
 * Created by raviw on 11/15/2017.
 */
public class BBDividendGrowth extends OctoBaseBox {

    public void process(SortedMap<String, Instrument> filteredlist) {
        clearFilteredInstruments();

        SortedMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameter = params.getParameter("Dividends");
                if (parameter != null && parameter.getValidCount() > 5 ) {
                    Double mean = parameter.getAverage();
                    int size = parameter.getSize();
                    Double latest = parameter.getValue(size - 1);
                    if (latest.isNaN() == false) {
                        Double growth = ((latest - mean) / mean) * 100;

                        if (growth > 1.0) {
                            Logger.logDebug("printing dividend growth for " + instrument + " - is : " + growth, OctoDefs.LOG_LEVEL_DEBUG);
                            writeblackboxfile("printing dividend growth for " + instrument + " - is : " + growth);
                            addFilteredInstrument(instrument, instemp);
                        }
                    }
                }
            }
            instemp.release_parameter();
        }
    }
}
