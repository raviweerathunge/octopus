package com.matrix.octopus.blackbox;

import com.matrix.octopus.*;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;

import java.util.Map;
import java.util.SortedMap;

/**
 * Created by raviw on 12/22/2017.
 */
public class BBGrowthToEarnings extends OctoBaseBox  {
    public void process(SortedMap<String, Instrument> filteredlist) {
        clearFilteredInstruments();

        SortedMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        writeblackboxfile("INSTRUMENT" + "," + "DESCRIPTION" + "," + "GROWTH-TO_EARNINGS" + "," + "GROWTH" + "," + "DIVIDEND-GROWTH" + "," + "PE");

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameterEarnings = params.getParameter("Earnings Per Share");
                Parameter parameterDividends = params.getParameter("Dividends");

                if (parameterEarnings != null && parameterEarnings.getSize() > 3) {

                    int size = parameterEarnings.getSize();

                    Double last = parameterEarnings.getValue(size - 2);
                    Double previous = parameterEarnings.getValue(size - 3);

                    if (last.isNaN() == false && previous.isNaN() == false) {
                        PriceInfo priceInfo = instemp.getlatestpriceinfo();
                        if (priceInfo != null) {

                            Double peRatio = priceInfo.getClose() / last;
                            Double growth = ((last - previous) / previous) * 100;

                            Double dividendGrowth = 0.0;
                            if (parameterDividends != null && parameterDividends.getValidCount() > 5 )
                                dividendGrowth = parameterDividends.getAverage();

                            if (dividendGrowth.isNaN() == false && dividendGrowth > 0.0 && growth > 0.0 && growth.isNaN() == false && peRatio.isNaN() == false && peRatio > 0.0) {

                                Double growthtoearnings = (growth +  dividendGrowth) / peRatio;

                                if (growthtoearnings > 0 && growthtoearnings.isNaN() == false) {
                                    Logger.logDebug("printing price / earnings history for " + instrument + " - is : " + peRatio, OctoDefs.LOG_LEVEL_DEBUG);
                                    writeblackboxfile(instrument + "," + instemp.get_instrumentdescription() + "," + growthtoearnings + "," + growth + "," + dividendGrowth + "," + peRatio);
                                    addFilteredInstrument(instrument, instemp);
                                }
                            }
                        }
                    }
                 }
            }
            instemp.release_parameter();
        }
    }
}
