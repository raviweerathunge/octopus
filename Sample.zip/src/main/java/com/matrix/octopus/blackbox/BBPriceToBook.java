package com.matrix.octopus.blackbox;

import com.matrix.octopus.*;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;

import java.util.Map;
import java.util.SortedMap;

/**
 * Created by raviw on 11/20/2017.
 */
public class BBPriceToBook extends OctoBaseBox {

    public void process(SortedMap<String, Instrument> filteredlist) {
        clearFilteredInstruments();

        SortedMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameter = params.getParameter("Book Value Per Share");
                Parameter parameterEarnings = params.getParameter("Earnings Per Share");

                if (parameterEarnings != null && parameter != null && parameter.getLatest().isNaN() == false && parameter.getLatest() != 0.0) {
                    PriceInfo priceInfo = instemp.getlatestpriceinfo();
                    if (priceInfo != null) {
                        Double pbRatio = priceInfo.getClose() / parameter.getLatest();
                        if (parameterEarnings.getAverage() > 0 && pbRatio < 1.5 && pbRatio > 0) {
                            Logger.logDebug("printing price / book history for " + instrument + " - is : " + pbRatio, OctoDefs.LOG_LEVEL_DEBUG);
                            writeblackboxfile(instrument + "," + instemp.get_instrumentdescription() + "," + pbRatio + "," + parameterEarnings.getAverage());
                            addFilteredInstrument(instrument, instemp);
                        }
                    }
                }
            }
            instemp.release_parameter();
        }
    }
}
