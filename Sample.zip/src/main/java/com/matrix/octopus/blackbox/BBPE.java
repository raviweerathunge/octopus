package com.matrix.octopus.blackbox;

import com.matrix.octopus.*;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;

import java.util.Map;
import java.util.SortedMap;

/**
 * Created by raviw on 12/11/2017.
 */
public class BBPE extends OctoBaseBox {
    public void process(SortedMap<String, Instrument> filteredlist) {
        clearFilteredInstruments();

        SortedMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        writeblackboxfile("INSTRUMENT" + "," + "DESCRIPTION" + "," + "PE");


        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameterEarnings = params.getParameter("Earnings Per Share");
                Parameter parameterCapital = params.getParameter("Shares Mil");

                if (parameterEarnings != null && parameterEarnings.getLatest().isNaN() == false && parameterEarnings.getLatest() > 0) {
                    PriceInfo priceInfo = instemp.getlatestpriceinfo();
                    if (priceInfo != null) {
                        Double peRatio = priceInfo.getClose() / parameterEarnings.getLatest();
                        if (parameterCapital != null)

                        if (peRatio < 15 && peRatio > 0) {
                            Logger.logDebug("printing price / earnings history for " + instrument + " - is : " + peRatio, OctoDefs.LOG_LEVEL_DEBUG);
                            writeblackboxfile(instrument + "," + instemp.get_instrumentdescription() + "," + peRatio);
                            addFilteredInstrument(instrument, instemp);
                        }
                    }
                }
            }
            instemp.release_parameter();
        }
    }
}
