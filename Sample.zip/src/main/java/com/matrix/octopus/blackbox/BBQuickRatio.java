package com.matrix.octopus.blackbox;

import com.matrix.octopus.Instrument;
import com.matrix.octopus.Logger;
import com.matrix.octopus.Parameter;
import com.matrix.octopus.Parameters;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;

import java.util.Map;
import java.util.SortedMap;

/**
 * Created by raviw on 11/15/2017.
 */
public class BBQuickRatio extends OctoBaseBox {

    public void process(SortedMap<String, Instrument> filteredlist) {
        clearFilteredInstruments();

        SortedMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameter = params.getParameter("Quick Ratio");
                if (parameter != null && parameter.getValidCount() > 5 && parameter.getAverage() > 1.0) {
                    Logger.logDebug("printing quick ration history for " + instrument + " - is : " + parameter.getAverage(), OctoDefs.LOG_LEVEL_DEBUG);
                    writeblackboxfile("printing quick ratio history for " + instrument + " - is : " + parameter.getAverage());
                    addFilteredInstrument(instrument , instemp);
                }
            }
            instemp.release_parameter();
        }
    }
}
