package com.matrix.octopus;

import com.matrix.octopus.octo.OctoDefs;
import org.ojalgo.finance.data.YahooSymbol;
import org.ojalgo.type.CalendarDate;
import org.ojalgo.type.CalendarDateUnit;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

/**
 * Created by raviw on 10/28/2017.
 */
public class FileHandler {

    public boolean downloadFile(String urlpath, String outfolder, String outfilename) {
        boolean result = false;
        try {
            URL url = new URL(urlpath);
            URLConnection urlConn = url.openConnection();
            InputStreamReader inputStreamReader = new InputStreamReader(urlConn.getInputStream());
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String outpath = outfolder + "/" + outfilename;
            BufferedWriter writer = Files.newBufferedWriter(Paths.get(outpath), StandardCharsets.UTF_8);
            String inputtext;
            while ((inputtext = bufferedReader.readLine()) != null) {
                writer.write(inputtext);
                writer.newLine();
            }
            bufferedReader.close();
            writer.close();
            inputStreamReader.close();
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            if (result == true)
                Logger.logDebug("download successfull -" + outfilename , OctoDefs.LOG_LEVEL_DEBUG);
        }

        return result;
    }

    public boolean downloadStockHistory(String name , String outfolder, String outfilename) {
        System.setProperty("http.proxyHost", "10.2.58.62");
        System.setProperty("http.proxyPort", "8080");

        boolean result = false;
        try {
            String symbol = name + "." + OctoDefs.YHOO_EXCHANGE_CODE;
            YahooSymbol historyData = new YahooSymbol(symbol, CalendarDateUnit.DAY);

            String outpath = outfolder + "/" + outfilename;
            BufferedWriter writer = Files.newBufferedWriter(Paths.get(outpath), StandardCharsets.UTF_8);

            String open , high , low , close , adjustedclose , volume , pricedate;
            CalendarDate date;
            List<YahooSymbol.Data> historyList =  historyData.getHistoricalPrices();

            if (historyList.size() > 0) {
                for (int i = (historyList.size() - 1); i == 0; i--) {
                    open = String.valueOf(historyList.get(i).open);
                    high = String.valueOf(historyList.get(i).high);
                    low = String.valueOf(historyList.get(i).low);
                    close = String.valueOf(historyList.get(i).close);
                    adjustedclose = String.valueOf(historyList.get(i).adjustedClose);
                    volume = String.valueOf(historyList.get(i).volume);
                    date = historyList.get(i).getKey();

                    pricedate = date.toString();
                    String trimdate = pricedate.substring(0, 10);

                    CSVUtils.writeLine(writer, Arrays.asList(open, high, low, close, adjustedclose, volume, trimdate));
                }
            }

            writer.close();
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            if (result == true)
                Logger.logDebug("download stock history successfull -" + name , OctoDefs.LOG_LEVEL_DEBUG);
            else
                Logger.logDebug("error downloading stock history -" + name , OctoDefs.LOG_LEVEL_DEBUG);
        }

        return result;
    }

    public boolean fileExists(String path , String filename) {
        boolean result = false;
        String filepath = path + "/" + filename;
        Path filenamepath = Paths.get(filepath);

        if (Files.exists(filenamepath)) {
            result = true;
            Logger.logDebug("file already exists -" + filenamepath , OctoDefs.LOG_LEVEL_DEBUG);
        }

        return result;
    }
}
