package com.matrix.octopus;

import com.matrix.octopus.octo.OctoDefs;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by raviw on 11/4/2017.
 */
public class CSVUtils {
    private static final char DEFAULT_SEPARATOR = ',';
    private static final char DEFAULT_QUOTE = '"';

    final static Pattern quote = Pattern.compile("^\\s*\"((?:[^\"]|(?:\"\"))*?)\"\\s*,");

    public static List<String> parseLine(String line)
    {
        List<String> list = new ArrayList<String>();
        line += ",";

        for (int x = 0; x < line.length(); x++)
        {
            String s = line.substring(x);
            if (s.trim().startsWith("\""))
            {
                Matcher m = quote.matcher(s);
                if (!m.find()) {
                    Logger.logDebug("CSV is malformed", OctoDefs.LOG_LEVEL_DEBUG);
                    return list;
                }
                list.add(m.group(1).replace("\"\"", "\""));
                x += m.end() - 1;
            }
            else
            {
                int y = s.indexOf(DEFAULT_SEPARATOR);
                if (y == -1) {
                    Logger.logDebug("CSV is malformed", OctoDefs.LOG_LEVEL_DEBUG);
                    return list;
                }
                list.add(s.substring(0, y));
                x += y;
            }
        }
        return list;
    }


    public static void writeLine(Writer w, List<String> values) throws IOException {
        writeLine(w, values, DEFAULT_SEPARATOR, DEFAULT_QUOTE);
    }

    public static void writeLine(Writer w, List<String> values, char separators) throws IOException {
        writeLine(w, values, separators, DEFAULT_QUOTE);
    }

    //https://tools.ietf.org/html/rfc4180
    private static String followCVSformat(String value) {

        String result = value;
        if (result.contains("\"")) {
            result = result.replace("\"", "\"\"");
        }
        return result;

    }

    private static void writeLine(Writer w, List<String> values, char separators, char customQuote) throws IOException {

        boolean first = true;

        //default customQuote is empty

        if (separators == ' ') {
            separators = DEFAULT_SEPARATOR;
        }

        StringBuilder sb = new StringBuilder();
        for (String value : values) {
            if (!first) {
                sb.append(separators);
            }
            if (customQuote == ' ') {
                sb.append(followCVSformat(value));
            } else {
                sb.append(customQuote).append(followCVSformat(value)).append(customQuote);
            }

            first = false;
        }
        sb.append("\n");
        w.append(sb.toString());
    }
}
