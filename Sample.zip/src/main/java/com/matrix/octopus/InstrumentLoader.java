package com.matrix.octopus;

import com.matrix.octopus.octo.OctoDefs;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.*;

/**
 * Created by raviw on 11/2/2017.
 */
public class InstrumentLoader {
    private SortedMap<String, Instrument> instruments = new TreeMap<String, Instrument>();

    public SortedMap<String, Instrument> getInstruments() {
        return instruments;
    }

    private boolean addInstrument(String id , String name , String sector){
        if (this.instruments.get(name) != null)
            return false;
        Instrument ins = new Instrument(id ,name , sector);
        this.instruments.put(id , ins);
        return true;
    }

    public synchronized boolean loadInstrument(String filename) {

        boolean result = false;
        int filecount = 0;
        String line = "";
        try {
            FileInputStream fis = new FileInputStream(filename);
            BufferedReader in = new BufferedReader(new InputStreamReader(fis));
            while ((line = in.readLine()) != null) {
                List<String> instrumentdetails = CSVUtils.parseLine(line);
                if (instrumentdetails.size() == 3) {
                    Logger.logDebug("reading instrunment - id - " + instrumentdetails.get(0), OctoDefs.LOG_LEVEL_DEBUG);
                    this.addInstrument(instrumentdetails.get(0) , instrumentdetails.get(1) , instrumentdetails.get(2));
                    filecount++;
                }
            }
            in.close();
            fis.close();
            result = true;
            Logger.logDebug("reading instrunments completed" + "\n" , OctoDefs.LOG_LEVEL_DEBUG);
        } catch (Exception e) {
            e.printStackTrace();
            result = false;
        }
        Logger.logDebug("total files read - " + filecount + "\n" , OctoDefs.LOG_LEVEL_DEBUG);
        return result;
    }

    public synchronized void writeValidInstruments(String filename) {
        try {
            FileWriter writer = new FileWriter(filename);

            String line = "";
            Instrument inst = null;

            for (Map.Entry<String, Instrument> entry : instruments.entrySet()) {
                line = entry.getKey();
                inst = entry.getValue();

                CSVUtils.writeLine(writer, Arrays.asList(inst.get_instrumentname(), inst.get_instrumentdescription(), inst.get_sector()));
            }

            writer.flush();
            writer.close();
        }
        catch (Exception e) {
            e.printStackTrace();
            Logger.logDebug("error saving valid instruments" + "\n" , OctoDefs.LOG_LEVEL_DEBUG);
        }
    }

    public synchronized Instrument findInstrument(String name) {
        return this.instruments.get(name);
    }

    public synchronized void removeInstrument(String name) {
        this.instruments.remove(name);
    }
}
