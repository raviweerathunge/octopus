package com.matrix.octopus.octo;

import com.matrix.octopus.*;

import java.io.BufferedWriter;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * Created by raviw on 11/14/2017.
 */
public class OctoBaseBox implements OctoBlackBox {

    // OctoBlackBox interface override methods
    public void init(RegistryEntry regentry , InstrumentLoader loader) {
        entry = regentry;
        instrumentLoader = loader;
    }
    public void start() {
        String filename = entry.getItemname() + "_" + String.valueOf(entry.getItemcpu()) + ".txt";

        String folder = OctoDefs.BLACK_BOX_OUT_FOLDER +  OctoDefs.EXCHANGE_CODE;
        openblackboxfile(OctoDefs.BLACK_BOX_OUT_FOLDER +  OctoDefs.EXCHANGE_CODE + "/" + filename);
    }
    public void process(SortedMap<String, Instrument> filteredlist) {}
    public void stop() {
        closeblackboxfile();
    }
    public void cleanup() {}
    public int getProgress() {
        return 0;
    }
    public String getName() {
        return entry.getItemname();
    }
    public int getID() {
        return entry.getItemid();
    }

    // File output methods.
    public boolean openblackboxfile(String filename) {
        try {
            writer = Files.newBufferedWriter(Paths.get(filename), StandardCharsets.UTF_8);
        }
        catch (Exception e) {
            return false;
        }
        return true;
    }

    public boolean closeblackboxfile() {
        try {
            if (writer != null)
                writer.close();
        }
        catch (Exception e) {
            return false;
        }

        return true;
    }

    public boolean writeblackboxfile(String line) {
        try {
            if (writer != null) {
                writer.write(line);
                writer.newLine();
            }
        }
        catch (Exception e) {
            return false;
        }

        return true;
    }

    public void addFilteredInstrument(String name , Instrument instrument) {
        filteredinstruments.put(name , instrument);
    }

    public SortedMap<String, Instrument> getFilteredinstruments() {
        return filteredinstruments;
    }

    public void clearFilteredInstruments() {
        filteredinstruments.clear();
    }

    public String getParentBox() {
        return entry.getParentName();
    }

    public OctoUtils getOctoUtils() {
        return octoUtils;
    }

    public void calcProfit() {

        Double total = 0.0;

        for (Map.Entry<String, Instrument> entry : filteredinstruments.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);

            PriceInfo priceInfoLatest = instemp.getlatestpriceinfo();
            PriceInfo priceInfoOldest = instemp.getoldestpriceinfo();
            if (priceInfoLatest != null && priceInfoOldest != null) {
                Double latestprice = priceInfoLatest.getClose();
                Double oldestprice = priceInfoOldest.getClose();

                Double quantity = 1000 / oldestprice;
                long quantitynew =  quantity.longValue();

                Double currentTotal = quantitynew * latestprice;
                Double oldTotal = quantitynew * oldestprice;
                Double profit = currentTotal - oldTotal;

                total += profit;
            }
        }

        writeblackboxfile("--------------------------------------------------------");
        Logger.logDebug("Profit reached is : " + total ,  OctoDefs.LOG_LEVEL_DEBUG);
        writeblackboxfile("Profit reached is : " +  total);
    }

    protected RegistryEntry entry = null;
    protected InstrumentLoader instrumentLoader = null;
    protected BufferedWriter writer = null;

    protected SortedMap<String, Instrument> filteredinstruments = new TreeMap<String, Instrument>();

    protected OctoUtils octoUtils = new OctoUtils();
}
