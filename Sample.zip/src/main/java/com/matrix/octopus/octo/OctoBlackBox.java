package com.matrix.octopus.octo;

import com.matrix.octopus.Instrument;
import com.matrix.octopus.InstrumentLoader;
import com.matrix.octopus.RegistryEntry;

import java.util.SortedMap;

/**
 * Created by raviw on 11/10/2017.
 */
interface  OctoBlackBox {
    public void init(RegistryEntry regentry , InstrumentLoader loader);
    public void start();
    public void process(SortedMap<String, Instrument> filteredlist);
    public void stop();
    public void cleanup();

    public int getProgress();
    public String getName();
    public int getID();
    public String getParentBox();
}
