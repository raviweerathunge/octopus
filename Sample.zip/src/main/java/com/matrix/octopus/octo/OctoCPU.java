package com.matrix.octopus.octo;

import com.matrix.octopus.Instrument;
import com.matrix.octopus.InstrumentLoader;
import com.matrix.octopus.Logger;
import com.matrix.octopus.Registry;

import java.util.ArrayList;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

/**
 * Created by raviw on 11/10/2017.
 */
public class OctoCPU implements Runnable {
    private Registry octoregistry;
    private int cpuid = 0;

    public OctoCPU(int id , InstrumentLoader instrumentLoader , Registry registry) {
        this.octoregistry = registry;
        this.cpuid = id;
    }

    @Override
    public void run() {
        try {
            Logger.logDebug(Thread.currentThread().getName() + " processing.." , OctoDefs.LOG_LEVEL_DEBUG);
            ArrayList<OctoBaseBox> bbarray = octoregistry.getBlackBoxForCpu(cpuid);
            int size = bbarray.size();
            String lastboxname = "";
            SortedMap<String, Instrument> filteredlist = null;
            for(int i=0;i<size;i++) {
                OctoBaseBox bb = bbarray.get(i);
                if (bb != null) {
                    Logger.logDebug("starting black box - " + bb.getName() , OctoDefs.LOG_LEVEL_DEBUG);
                    bb.start();
                    String temp = bb.getParentBox();
                    if (temp.equals("") == false) {
                        if (temp.equals(lastboxname) == true) {
                            bb.process(filteredlist);
                        }
                    }
                    else {
                        bb.process(new TreeMap<>());
                    }
                    bb.stop();
                    lastboxname = bb.getName();
                    filteredlist = bb.getFilteredinstruments();
                    Logger.logDebug("completed black box - " + bb.getName() , OctoDefs.LOG_LEVEL_DEBUG);
                }
            }
            Logger.logDebug(Thread.currentThread().getName() + " completed" , OctoDefs.LOG_LEVEL_DEBUG);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
