package com.matrix.octopus.octo;

import com.matrix.octopus.*;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Created by raviw on 11/2/2017.
 */
@Component
public class Octopus implements CommandLineRunner {

    private InstrumentLoader instrumentLoader;
    private FileHandler filehandler;
    private FileParser fileparser;
    private Registry registry;

    public static OctoFactory octofactory = new OctoFactory();

    private boolean processing = true;
    ArrayList<Thread> threads = new ArrayList<Thread>();

    @Autowired
    public Octopus(InstrumentLoader loader , FileHandler handler , FileParser parser , Registry cpuRegister) {
        this.instrumentLoader = loader;
        this.filehandler = handler;
        this.fileparser = parser;
        this.registry = cpuRegister;

        System.setProperty("http.proxyHost", "10.2.58.62");
        System.setProperty("http.proxyPort", "8080");
    }

    @Override
    public void run(String... args) throws Exception {
        startProcessing();
    }

    private boolean startProcessing() throws InterruptedException {

        String line = "";
        Instrument instrument = null;

        Logger.init(OctoDefs.LOG_LEVEL_DEBUG);

        String regfolder = OctoDefs.AFFINIT_FILE_PATH;
        boolean regload = registry.loadRegistryEntries(regfolder);
        if (regload == false) {
            Logger.logDebug("error loading registry" , OctoDefs.LOG_LEVEL_DEBUG);
            return false;
        }

        fileparser.init();
        boolean insresult = instrumentLoader.loadInstrument(OctoDefs.INSTRUMENT_FILE_PATH);

        if (insresult == true)
        {
            SortedMap<String, Instrument> instrumentlist = instrumentLoader.getInstruments();
            ArrayList<String> delistedinstruments = new ArrayList<>();
            for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet())  {
                line = entry.getKey();
                instrument = entry.getValue();
                Logger.logDebug("reading instrunment - " + line , OctoDefs.LOG_LEVEL_DEBUG);

                boolean result = false;
                String folder = OctoDefs.FINANCIAL_OUT_FOLDER + OctoDefs.EXCHANGE_CODE + "/" + line;
                String bbfolder = OctoDefs.BLACK_BOX_OUT_FOLDER +  OctoDefs.EXCHANGE_CODE;
                File theDir = new File(folder);
                if (!theDir.exists()) {
                    Logger.logDebug("creating directory: " + theDir.getName() , OctoDefs.LOG_LEVEL_DEBUG);
                    try {
                        theDir.mkdir();
                        result = true;
                    } catch (SecurityException se) {
                        Logger.logDebug("error creating directory: " + theDir.getName() , OctoDefs.LOG_LEVEL_DEBUG);
                    }
                } else {
                    result = true;
                }

                theDir = new File(bbfolder);
                if (!theDir.exists()) {
                    try {
                        theDir.mkdir();
                        Logger.logDebug("creating blackbox directory: " + theDir.getName() , OctoDefs.LOG_LEVEL_DEBUG);
                    } catch (SecurityException se) {
                        Logger.logDebug("error creating blackbox directory: " + theDir.getName() , OctoDefs.LOG_LEVEL_DEBUG);
                    }
                }

                if (result == true){
                    ////
                    String urlpath = String.format("http://financials.morningstar.com/ajax/exportKR2CSV.html?t=%s:%s" , OctoDefs.EXCHANGE_CODE , line);
                    String filename = line + OctoDefs.RATIO_FILE_NAME_PREFIX;
                    if (!filehandler.fileExists(folder , filename) || OctoDefs.FILE_OVERWRITE == true)
                        filehandler.downloadFile(urlpath , folder , filename);

                    urlpath = String.format("http://financials.morningstar.com/ajax/ReportProcess4CSV.html?t=%s:%s&reportType=is&period=12&dataType=A&order=asc&columnYear=5&number=3", OctoDefs.EXCHANGE_CODE , line);
                    filename = line + OctoDefs.INCOME_STATEMENT_FILE_NAME_PREFIX;
                    if (!filehandler.fileExists(folder , filename) || OctoDefs.FILE_OVERWRITE == true)
                        filehandler.downloadFile(urlpath , folder , filename);

                    urlpath = String.format("http://financials.morningstar.com/ajax/ReportProcess4CSV.html?t=%s:%s&reportType=cf&period=12&dataType=A&order=asc&columnYear=5&number=3", OctoDefs.EXCHANGE_CODE , line);
                    filename = line +OctoDefs.CASH_FLOW_STATEMENT_FILE_NAME_PREFIX;
                    if (!filehandler.fileExists(folder , filename) || OctoDefs.FILE_OVERWRITE == true)
                        filehandler.downloadFile(urlpath , folder , filename);

                    urlpath = String.format("http://financials.morningstar.com/ajax/ReportProcess4CSV.html?t=%s:%s&reportType=bs&period=12&dataType=A&order=asc&columnYear=5&number=3", OctoDefs.EXCHANGE_CODE , line);
                    filename = line + OctoDefs.BALANCE_SHEET_STATEMENT_FILE_NAME_PREFIX;
                    if (!filehandler.fileExists(folder , filename) || OctoDefs.FILE_OVERWRITE == true)
                        filehandler.downloadFile(urlpath , folder , filename);

                    LocalDate date = LocalDate.now();
                    LocalDate olddate = date.minusYears(OctoDefs.OCTO_HISTORY_DATA_YEARS);

                    String to = date.toString();
                    String from = olddate.toString();

                    // urlpath = String.format("http://globalquote.morningstar.com/globalcomponent/RealtimeHistoricalStockData.ashx?ticker=XASX:%s&showVol=false&dtype=his&f=d&curry=AUD&range=%s|%s&isD=false&isS=false&hasF=false&ProdCode=DIRECT", line , from ,to);
                    //urlpath = String.format("http://www.asx.com.au/b2c-api/1/share/%s/prices?interval=daily&count=1000" , line);
                    filename = line + OctoDefs.PRICE_FILE_NAME_PREFIX;
                    boolean downloaded = filehandler.fileExists(folder , filename);
                    if (!downloaded || OctoDefs.FILE_OVERWRITE == true) {
                        if (filehandler.downloadStockHistory(line, folder, filename)) {
                            downloaded = true;
                        }
                    }

                    if (downloaded) {
                        ArrayList<PriceInfo> pricelist = fileparser.parsepricefile_yhoo(folder, filename);
                        instrument.set_pricelist(pricelist);
                        Logger.logDebug("price history array size - " + String.valueOf(pricelist.size()) , OctoDefs.LOG_LEVEL_DEBUG);
                    }
                    else {
                        ArrayList<PriceInfo> pricelist = new ArrayList<>();
                        instrument.set_pricelist(pricelist);
                        delistedinstruments.add(line);
                    }
                }
                System.out.print("\n");
            }

            /// Remove delisted instruments
            int removecount = delistedinstruments.size();
            for(int i=0;i<removecount;i++) {
                String instrumentname = delistedinstruments.get(i);
                instrumentLoader.removeInstrument(instrumentname);

                // Remove instrument folder
                String folder = OctoDefs.FINANCIAL_OUT_FOLDER + OctoDefs.EXCHANGE_CODE + "/" + instrumentname;

                File file = new File(folder);
                OctoUtils.deleteDirectory(file);
            }

            instrumentLoader.writeValidInstruments(OctoDefs.INSTRUMENT_FILE_PATH);

            scanParameters();
            startCPUs();
        }
        else
            Logger.logDebug("error reading file - " + OctoDefs.INSTRUMENT_FILE_PATH , OctoDefs.LOG_LEVEL_DEBUG);

        return insresult;
    }

    private void scanParameters() {
        String line = "";
        Instrument inst = null;
        SortedMap<String, Instrument> instrumentlist = instrumentLoader.getInstruments();
        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            line = entry.getKey();
            inst = entry.getValue();
            Logger.logDebug("scanning instrument details - " + line , OctoDefs.LOG_LEVEL_DEBUG);
            String filename = line + OctoDefs.RATIO_FILE_NAME_PREFIX;
            String folder = OctoDefs.FINANCIAL_OUT_FOLDER + OctoDefs.EXCHANGE_CODE + "/" +  line;
            Parameters params = fileparser.parseratiofile(folder , filename);
            if (params != null) {
                inst.set_parameter(params);
            }
        }
    }

    private void startCPUs() throws InterruptedException {
        ExecutorService executor = Executors.newFixedThreadPool(OctoDefs.CPU_COUNT);

        for (int i=0 ; i < OctoDefs.CPU_COUNT ; i++) {
            executor.execute(new OctoCPU(i , instrumentLoader , registry));
        }

        executor.shutdown();
        executor.awaitTermination(Long.MAX_VALUE, TimeUnit.MINUTES);
        Logger.logDebug("all cpus completed processing" , OctoDefs.LOG_LEVEL_DEBUG);
    }

}
