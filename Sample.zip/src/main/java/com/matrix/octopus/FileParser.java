package com.matrix.octopus;

import com.matrix.octopus.octo.OctoDefs;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

/**
 * Created by raviw on 11/2/2017.
 */
public class FileParser {

    private SortedMap<String, TagInfo> taglist = new TreeMap<String, TagInfo>();

    public void init() {
        /// Move the taglist to XML in the future
        addTagInfo("Revenue AUD Mil" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Revenue NZD Mil" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Gross Margin %" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Net Income" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Earnings Per Share" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Dividends" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Book Value Per Share" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Working Capital" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("R&D" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Return on Assets" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Return on Equity" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Return on Invested Capital" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Interest Coverage" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Current Ratio" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Quick Ratio" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Financial Leverage (Average)" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Debt/Equity" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Shares Mil" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
    }

    private void addTagInfo(String tag , int count) {
        TagInfo tagInfo = new TagInfo(tag , count);
        taglist.put(tag , tagInfo);
    }

    public Parameters parseratiofile(String folder , String filename) {

        String outpath = folder + "/" + filename;
        BufferedReader bufferedReader = null;
        String line = "";

        Parameters params = new Parameters();
        //Logger.logDebug("reading file - " + outpath , OctoDefs.LOG_LEVEL_DEBUG);
        try {
            bufferedReader = new BufferedReader(new FileReader(new File(outpath)));
            while ((line = bufferedReader.readLine()) != null) {
                List<String> result = CSVUtils.parseLine(line);

                if (result.size() > 1) {
                    String keyvalue = result.get(0);
                    TagInfo taginfo = isTagListValue(keyvalue);
                    if (taginfo != null){
                        // This is inside our requirement list. Need to parse and get the value.
                        result.remove(0);
                        Parameter param = new Parameter();
                        param.set_name(taginfo.get_name());
                        param.set_tagInfo(taginfo);
                        param.parseValues(result);
                        params.addParameter(taginfo.get_name() , param);
                        //Logger.logDebug(keyvalue , OctoDefs.LOG_LEVEL_DEBUG);
                    }
                }
            }
        }catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            //Logger.logDebug("======================================================================" , OctoDefs.LOG_LEVEL_DEBUG);
        }

        return params;
    }

    public ArrayList<PriceInfo> parsepricefile_morningstar(String outfolder , String outfilename) {
        String outpath = outfolder + "/" + outfilename;
        ArrayList<PriceInfo> pricelist = new ArrayList<PriceInfo>();
        try {
                String inputtext = new String(Files.readAllBytes(Paths.get(outpath)));
                int index = inputtext.indexOf("Datapoints");
                if (index >= 0) {
                    int indexstart = inputtext.indexOf("[[", index);
                    indexstart++;
                    int indexend = inputtext.indexOf("]]", indexstart);
                    if (indexstart >=0 && indexend >=0 && indexend > indexstart) {
                        String prices = inputtext.substring(indexstart, indexend);

                        String r1 = "(^.*?\\[|\\]\\s*$)", r2 = "\\]\\s*,\\s*\\[";
                        String[] ss = prices.replaceAll(r1,"").split(r2);

                        for (String element : ss) {
                            PriceInfo priceinfo = new PriceInfo();
                            List<String> result = CSVUtils.parseLine(element);
                            int size = result.size();
                            for (int i=0;i<size;i++) {
                                Double value = Double.parseDouble(result.get(i));
                                priceinfo.setPrice(i,value);
                            }
                            pricelist.add(priceinfo);
                        }
                    }
                }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return pricelist;
    }

    public ArrayList<PriceInfo> parsepricefile_asx(String outfolder , String outfilename) {
        String outpath = outfolder + "/" + outfilename;
        ArrayList<PriceInfo> pricelist = new ArrayList<PriceInfo>();
        try {
                JSONParser parser = new JSONParser();

                Object obj = null;

                try {
                    obj = parser.parse(new FileReader(outpath));
                } catch (Exception e) {
                    e.printStackTrace();
                    return pricelist;
                }

                JSONObject jsonObject = (JSONObject)obj;

                JSONArray msg = (JSONArray) jsonObject.get("data");
                int size = msg.size();
                for (int i=0;i<size;i++) {
                    JSONObject jasonchild = (JSONObject)msg.get(i);
                    Number closeprice = (Number)jasonchild.get("close_price");
                    Number dayhigh = (Number)jasonchild.get("day_high_price");
                    Number daylow = (Number)jasonchild.get("day_low_price");
                    Number volume = (Number)jasonchild.get("volume");
                    String date = (String)jasonchild.get("close_date");

                    PriceInfo priceinfo = new PriceInfo();
                    priceinfo.setPrice(0,closeprice.doubleValue());
                    priceinfo.setPrice(1,dayhigh.doubleValue());
                    priceinfo.setPrice(2,daylow.doubleValue());
                    priceinfo.setPrice(3,closeprice.doubleValue());
                    priceinfo.setVolume(volume.doubleValue());
                    priceinfo.setDate(date);
                    pricelist.add(priceinfo);
                }
            }
        catch (Exception e) {
            e.printStackTrace();
        }

        return pricelist;
    }

    public ArrayList<PriceInfo> parsepricefile_yhoo(String outfolder , String outfilename) {
        String outpath = outfolder + "/" + outfilename;
        ArrayList<PriceInfo> pricelist = new ArrayList<PriceInfo>();
        try {
            FileInputStream fis = new FileInputStream(outpath);
            BufferedReader in = new BufferedReader(new InputStreamReader(fis));

            String line = "";
            while ((line = in.readLine()) != null && pricelist.size() <= OctoDefs.OCTO_MAX_PRICE_LEVELS) {
                List<String> pricedetails = CSVUtils.parseLine(line);

                PriceInfo priceinfo = new PriceInfo();
                priceinfo.setPrice(0,Double.parseDouble(pricedetails.get(4)));
                priceinfo.setPrice(1,Double.parseDouble(pricedetails.get(1)));
                priceinfo.setPrice(2,Double.parseDouble(pricedetails.get(2)));
                priceinfo.setPrice(3,Double.parseDouble(pricedetails.get(0)));
                priceinfo.setVolume(Double.parseDouble(pricedetails.get(5)));
                priceinfo.setDate(pricedetails.get(6));
                pricelist.add(priceinfo);
            }
            in.close();
            fis.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        return pricelist;
    }

    public TagInfo isTagListValue(String text) {

        for (Map.Entry<String, TagInfo> entry : taglist.entrySet()) {
            String tag = entry.getKey();

            if (text.indexOf(tag) == 0)
                return entry.getValue();
        }

       return null;
    }
}
