package com.matrix.octopus;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.apache.commons.math3.stat.descriptive.moment.StandardDeviation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static java.util.Collections.addAll;

/**
 * Created by raviw on 11/2/2017.
 */
public class Parameter {
    public String get_name() {
        return m_name;
    }

    public void set_name(String name) {
        this.m_name = name;
    }

    public void addValues(Double value) {
        m_values.add(value);
    }

    public Double getValue(int index) {
        return m_values.get(index);
    }

    public int getSize() {
        return m_values.size();
    }

    public int getValidCount() {
        return m_validcount;
    }

    public Double getAverage() {
        return m_stats.getMean();
    }

    public Double getMin() {
        return m_stats.getMin();
    }

    public Double getMax() {
        return m_stats.getMax();
    }

    public Double getStd() {
        return m_stats.getStandardDeviation();
    }

    public Double getSum() {
        return m_stats.getSum();
    }

    public Double getVariance() {
        return m_stats.getVariance();
    }

    public Double getLatest() {
        int size = m_values.size();
        for (int i=0;i<size;i++) {
            if (m_values.get(size - i -1).isNaN() == false)
                return m_values.get(size - i -1);
        }
        return Double.NaN;
    }

    public Double getPopulationVariance() {
        return m_stats.getPopulationVariance();
    }

    public void parseValues(List<String> result) {
        Double value = Double.NaN;
        int size = result.size();

        if (m_tagInfo != null && size > m_tagInfo.get_count())
            size = m_tagInfo.get_count();

        for (int i=0;i<size;i++) {
            try{
                if (result.get(i).isEmpty() == false) {
                    // replace thousand seperators
                    String tempResult = result.get(i).replaceAll(",","");
                    value = Double.parseDouble(tempResult);
                    m_stats.addValue(value);
                    m_validcount++;
                }
                else {
                    value = Double.NaN;
                }
                addValues(value);
            }
            catch (Exception e)  {

            }
        }
    }

    public TagInfo get_tagInfo() {
        return m_tagInfo;
    }

    public void set_tagInfo(TagInfo tagInfo) {
        this.m_tagInfo = tagInfo;
    }


    private int m_validcount = 0;
    private String m_name = "";
    private TagInfo m_tagInfo = null;
    private ArrayList<Double> m_values = new ArrayList<Double>();
    private DescriptiveStatistics m_stats = new DescriptiveStatistics();
}
