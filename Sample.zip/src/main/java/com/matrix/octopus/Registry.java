package com.matrix.octopus;

import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;
import com.matrix.octopus.octo.OctoFactory;
import com.matrix.octopus.octo.Octopus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.*;

/**
 * Created by raviw on 11/10/2017.
 */
@Component
public class Registry {
    private InstrumentLoader instrumentLoader;
    private OctoFactory octoFactory;
    private ArrayList<RegistryEntry> registryentries = new ArrayList<RegistryEntry>();

    @Autowired
    public Registry(InstrumentLoader loader , OctoFactory factory) {
        this.instrumentLoader = loader;
        this.octoFactory = factory;
    }

    public boolean loadRegistryEntries(String filepath) {
        try {
            File fXmlFile = new File(filepath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();

            String rootid = doc.getDocumentElement().getNodeName();
            Logger.logDebug("root element :" + rootid , OctoDefs.LOG_LEVEL_DEBUG);
            NodeList nList = doc.getElementsByTagName("box");
            Logger.logDebug("----------------------------" , OctoDefs.LOG_LEVEL_DEBUG);

            int count = nList.getLength();
            for (int i = 0; i < nList.getLength(); i++) {
                Node nNode = nList.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    String name = eElement.getAttribute("name");
                    String cpu = eElement.getElementsByTagName("cpu").item(0).getTextContent();
                    String parent = "";
                    if (eElement.getElementsByTagName("parent").item(0) != null)
                        parent = eElement.getElementsByTagName("parent").item(0).getTextContent();

                    Logger.logDebug("box name : " + name , OctoDefs.LOG_LEVEL_DEBUG);
                    Logger.logDebug("cpu : "  + cpu , OctoDefs.LOG_LEVEL_DEBUG);
                    Logger.logDebug("parent : "  + parent , OctoDefs.LOG_LEVEL_DEBUG);

                    RegistryEntry regentry = new RegistryEntry(i , name , Integer.parseInt(cpu) , parent);
                    registryentries.add(regentry);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public synchronized ArrayList<OctoBaseBox> getBlackBoxForCpu(int cpuid) {
        ArrayList<OctoBaseBox> listboxes = new ArrayList<OctoBaseBox>();

        RegistryEntry regentry = null;
        for (int i=0; i < registryentries.size() ; i++) {
            regentry = registryentries.get(i);
            if (regentry.getItemcpu() == cpuid) {
                OctoBaseBox bb = octoFactory.createBlackBox(regentry , instrumentLoader);
                if (bb != null) {
                    listboxes.add(bb);
                }
            }
        }
        return listboxes;
    }
}
