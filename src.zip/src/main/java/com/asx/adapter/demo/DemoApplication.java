package com.asx.adapter.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;

@SpringBootApplication
@EnableConfigurationProperties
public class DemoApplication implements CommandLineRunner {

	DBHandler handler = new DBHandler();
	FileHandler fileHandler = new FileHandler();

	public static void main(String[] args) {
		Properties systemProperties = System.getProperties();
		systemProperties.setProperty("http.proxyHost","10.2.58.62");
		systemProperties.setProperty("http.proxyPort","8080");

		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		String line = "MYX";
		int rowcount = 0;

		handler.connect();
		try {
			rowcount = handler.getTableRowCount(line);
		} catch (SQLException e) {
			try {
				handler.createPTabel(line);
			} catch (SQLException j) {
				j.printStackTrace();
			}
		}

		if (rowcount == 0) {
			ArrayList<PriceInfo> pricelist = fileHandler.parse("C:\\asxsoftware\\", "abc.log");
			handler.addBulk(line, pricelist);
		}
		else {
			//pricelist = handler.getPTableData(line);
			PriceInfo info = handler.getLatest(line);
			String lastDate = info.getDateString("yyyy-MM-dd");

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

			LocalDate today = LocalDate.now();
			today = today.minusDays(1);
			String latest = today.toString();

			LocalDate lastDateValue = LocalDate.parse(lastDate, formatter);
			lastDateValue = lastDateValue.plusDays(1);

			if (latest.equalsIgnoreCase(lastDate) == false) {
				LocalDate date = today;

				String urlpath = String.format("https://www.investopedia.com/markets/api/partial/historical/?Symbol=%s.%s&Type=Historical+Prices&Timeframe=Daily&StartDate=%s+%d%%2C+%d&EndDate=%s+%d%%2C+%d" , line , "XASX" , lastDateValue.getMonth().getDisplayName(TextStyle.SHORT,Locale.ENGLISH) , lastDateValue.getDayOfMonth() , lastDateValue.getYear() , date.getMonth().getDisplayName(TextStyle.SHORT,Locale.ENGLISH) , date.getDayOfMonth() , date.getYear());
				boolean ret = true;//fileHandler.downloadFile(urlpath,"C:\\asxsoftware\\", "abc.bk.log");
				if (ret) {
					ArrayList<PriceInfo> arrlist = fileHandler.parse("C:\\asxsoftware\\", "abc.bk.log");
					handler.addBulk(line, arrlist);

					PriceInfo latestinfo = handler.getLatest(line);
					rowcount = handler.getTableRowCount(line);
				}
			}
			else {
				///load from db
			}
		}
	}
}
