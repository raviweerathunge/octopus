package com.asx.adapter.demo;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.sql.*;
import java.util.ArrayList;

//@Component
@Configuration
@ConfigurationProperties(prefix="dbproperties")
public class DBHandler {
    private String connectionString = "jdbc:sqlite:C://asxsoftware/XASX.db";
    private Connection dbConnection;

    public String getConnectionString() { return connectionString; }
    public void setConnectionString(String url) { connectionString = url;}

    public DBHandler() {
    }

    /*@PostConstruct
    private void onPostConstruct() throws SQLException {
        connect();
    }*/

    public void connect() throws SQLException {
        // SQLite connection string
        String url = connectionString;
        dbConnection = DriverManager.getConnection(url);
    }

    public void executeSql(String sql) throws SQLException {
        Statement stmt = dbConnection.createStatement();
        stmt.execute(sql);
    }

    public void createPTabel(String tblName) throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS " + tblName + " " + "(\n"
                + "	date TEXT PRIMARY KEY,\n"
                + "	open REAL NOT NULL,\n"
                + "	high REAL NOT NULL,\n"
                + "	low REAL NOT NULL,\n"
                + "	close REAL NOT NULL,\n"
                + "	volume REAL NOT NULL" + ");";

        executeSql(sql);

        sql = "CREATE UNIQUE INDEX idx_date ON " + tblName + " (date)";
        executeSql(sql);
    }

    public void addData(String tblName , String date , Double d1 , Double d2 , Double d3 , Double d4) throws SQLException {
        String sql = "INSERT INTO " + tblName + "(date,open,high,low,close,volume) VALUES(?,?,?,?,?,?)";

        PreparedStatement pstmt = dbConnection.prepareStatement(sql);
        pstmt.setString(1, date);
        pstmt.setDouble(2, d1);
        pstmt.setDouble(3, d2);
        pstmt.setDouble(4, d3);
        pstmt.setDouble(5, d3);
        pstmt.setDouble(6, d4);
        pstmt.executeUpdate();
    }

    public void addBulk(String tblName , ArrayList<PriceInfo> priceInfo) throws SQLException {

        String sql = "INSERT INTO " + tblName + "(date,open,high,low,close,volume) VALUES(?,?,?,?,?,?)";
        PreparedStatement pstmt = dbConnection.prepareStatement(sql);

        int count = priceInfo.size();
        for(int i=0; i<count;i++) {
            PriceInfo price = priceInfo.get(i);

            pstmt.setString(1, price.getDateString("yyyy-MM-dd"));
            pstmt.setDouble(2, price.getOpen());
            pstmt.setDouble(3, price.getHigh());
            pstmt.setDouble(4, price.getLow());
            pstmt.setDouble(5, price.getClose());
            pstmt.setDouble(6, price.getVolume());

            pstmt.addBatch();
        }

        pstmt.executeBatch();
    }

    public Integer getTableRowCount(String tblName) throws SQLException {
        Integer count = 0;
        Statement st = dbConnection.createStatement();
        ResultSet res = st.executeQuery("SELECT COUNT(*) FROM "+tblName);
        while (res.next()) {
            count = res.getInt(1);
        }
        return count;
    }

    public ArrayList<PriceInfo> getPTableData(String tblName) throws SQLException {
        ArrayList<PriceInfo> data = new ArrayList<>();
        String sql = "SELECT date, open, high , low , close , volume FROM " + tblName;
        Statement stmt  = dbConnection.createStatement();
        ResultSet rs    = stmt.executeQuery(sql);

        // loop through the result set
        while (rs.next()) {
            PriceInfo priceInfo = new PriceInfo();
            priceInfo.setDate("yyyy-MM-dd",rs.getString("date"));
            priceInfo.setOpen(rs.getDouble("open"));
            priceInfo.setHigh(rs.getDouble("high"));
            priceInfo.setLow(rs.getDouble("low"));
            priceInfo.setClose(rs.getDouble("close"));
            priceInfo.setVolume(rs.getDouble("volume"));

            data.add(priceInfo);
        }
        return data;
    }

    public void dropTable(String tblName) throws SQLException {
        String sql = "DROP TABLE IF EXISTS " + tblName;
        executeSql(sql);
    }

    public PriceInfo getLatest(String tblName) throws SQLException {
        PriceInfo info = new PriceInfo() ;

        String sql = "SELECT * FROM " + tblName  + " ORDER BY date DESC LIMIT 1";
        Statement stmt  = dbConnection.createStatement();
        ResultSet rs    = stmt.executeQuery(sql);

        if (rs.next()) {
            info.setDate("yyyy-MM-dd",rs.getString("date"));
            info.setOpen(rs.getDouble("open"));
            info.setHigh(rs.getDouble("high"));
            info.setLow(rs.getDouble("low"));
            info.setClose(rs.getDouble("close"));
            info.setVolume(rs.getDouble("volume"));
        }

        return info;
    }
}
