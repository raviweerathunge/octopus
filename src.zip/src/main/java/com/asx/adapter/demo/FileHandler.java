package com.asx.adapter.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 * Created by raviw on 10/28/2017.
 */
public class FileHandler {

    private static Logger logger = LoggerFactory.getLogger(FileHandler.class);
    private DocumentBuilderFactory dbFactory;
    private DocumentBuilder dBuilder;

    public FileHandler() {
        dbFactory = DocumentBuilderFactory.newInstance();
        try {
            dBuilder = dbFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
    }

    public boolean downloadFile(String urlpath, String outfolder, String outfilename) {
        boolean result = false;
        BufferedReader bufferedReader = null;
        try {
            URL url = new URL(urlpath);
            URLConnection urlConn = url.openConnection();
            InputStreamReader inputStreamReader = new InputStreamReader(urlConn.getInputStream());
            bufferedReader = new BufferedReader(inputStreamReader);
            String outpath = outfolder + "/" + outfilename;
            BufferedWriter writer = Files.newBufferedWriter(Paths.get(outpath), StandardCharsets.UTF_8);
            String inputtext;
            while ((inputtext = bufferedReader.readLine()) != null) {
                writer.write(inputtext);
                writer.newLine();
            }
            bufferedReader.close();
            writer.close();
            inputStreamReader.close();
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            if (result == true)
                logger.debug("download successfull - {}" , outfilename);
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                    logger.debug("error closing buffer reader - {} - {} - {}" , urlpath , outfolder , outfilename);
                }
            }
        }

        return result;
    }

    public boolean fileExists(String path , String filename) {
        boolean result = false;
        String filepath = path + "/" + filename;
        Path filenamepath = Paths.get(filepath);

        if (Files.exists(filenamepath)) {
            result = true;
            logger.debug("file already exists - {}" , filenamepath);
        }

        return result;
    }

    public ArrayList<PriceInfo> parse(String outfolder , String outfilename) throws IOException, SAXException {
        String outpath = outfolder + "/" + outfilename;
        ArrayList<PriceInfo> pricelist = new ArrayList<PriceInfo>();

        File inputFile = new File(outpath);
        Document doc = dBuilder.parse(inputFile);
        doc.getDocumentElement().normalize();

        NodeList nList = doc.getElementsByTagName("tr");

        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element rootElement = (Element) nNode;

                if (rootElement.getAttribute("class").compareToIgnoreCase("in-the-money") == 0) {

                    PriceInfo priceinfo = new PriceInfo();

                    NodeList children = nNode.getChildNodes();
                    int count = 0;
                    for (int j = 0; j < children.getLength(); j++) {
                        Node childNode = children.item(j);

                        if (childNode.getNodeType() == Node.ELEMENT_NODE) {
                            Element eElement = (Element) childNode;
                            if (eElement.getAttribute("class").compareToIgnoreCase("date") == 0) {
                                priceinfo.setDate("MMMM d, yyyy",eElement.getTextContent());
                                count++;
                            }
                            else if (eElement.getAttribute("class").compareToIgnoreCase("num") == 0) {
                                if (count == 1) {
                                    priceinfo.setPrice(3,Double.parseDouble(eElement.getTextContent()));
                                    count++;
                                }
                                else if (count == 2) {
                                    priceinfo.setPrice(1,Double.parseDouble(eElement.getTextContent()));
                                    count++;
                                }
                                else if (count == 3) {
                                    priceinfo.setPrice(2,Double.parseDouble(eElement.getTextContent()));
                                    count++;
                                }
                                else if (count == 4) {
                                    priceinfo.setPrice(0,Double.parseDouble(eElement.getTextContent()));
                                    count++;
                                }
                                else if (count == 5) {
                                    String temp1 = eElement.getTextContent();
                                    priceinfo.setVolume(Double.parseDouble(eElement.getTextContent().replace(",","")));
                                    count++;
                                }
                            }
                        }
                    }

                    pricelist.add(priceinfo);
                }
            }
        }
        return pricelist;
    }
}
