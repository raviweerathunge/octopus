package com.matrix.octopus;

import com.matrix.octopus.octo.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.*;

/**
 * Created by raviw on 11/10/2017.
 */
@Component
public class Registry {
    private InstrumentLoader instrumentLoader;
    private OctoFactory octoFactory;
    private ArrayList<RegistryEntry> registryentries = new ArrayList<RegistryEntry>();
    private OctoConfigs octoConfigs;
    private static Logger logger = LoggerFactory.getLogger(Registry.class);

    @Autowired
    public Registry(OctoConfigs octoConfigs , InstrumentLoader loader , OctoFactory factory) {
        this.instrumentLoader = loader;
        this.octoFactory = factory;
        this.octoConfigs = octoConfigs;
    }

    public boolean loadRegistryEntries(String filepath) {
        try {
            File fXmlFile = new File(filepath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();

            String rootid = doc.getDocumentElement().getNodeName();
            logger.debug("root element : {}" , rootid);
            NodeList nList = doc.getElementsByTagName("box");
            logger.debug("----------------------------");

            int count = nList.getLength();
            for (int i = 0; i < nList.getLength(); i++) {
                Node nNode = nList.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    String name = eElement.getAttribute("name");
                    String cpu = eElement.getElementsByTagName("cpu").item(0).getTextContent();
                    String parent = "";
                    if (eElement.getElementsByTagName("parent").item(0) != null)
                        parent = eElement.getElementsByTagName("parent").item(0).getTextContent();

                    List<String> parameterList = new ArrayList<>();
                    Node parameters = eElement.getElementsByTagName("parameters").item(0);
                    if (parameters != null) {
                        NodeList childParamt = parameters.getChildNodes();
                        for (int p = 0; p < childParamt.getLength(); p++) {
                            Node child = childParamt.item(p);
                            if (child.getNodeType() == Node.ELEMENT_NODE) {
                                String paramvalue = child.getTextContent();
                                parameterList.add(paramvalue);
                            }
                        }
                    }

                    logger.debug("box name : {}" , name);
                    logger.debug("cpu : {}" , cpu);
                    logger.debug("parent : {}" , parent);

                    RegistryEntry regentry = new RegistryEntry(i , name , Integer.parseInt(cpu) , parent , parameterList);
                    registryentries.add(regentry);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public synchronized ArrayList<OctoBaseBox> getBlackBoxForCpu(int cpuid) {
        ArrayList<OctoBaseBox> listboxes = new ArrayList<OctoBaseBox>();

        RegistryEntry regentry = null;
        for (int i=0; i < registryentries.size() ; i++) {
            regentry = registryentries.get(i);
            if (regentry.getItemcpu() == cpuid) {
                OctoBaseBox bb = octoFactory.createBlackBox(octoConfigs ,  regentry , instrumentLoader);
                if (bb != null) {
                    listboxes.add(bb);
                }
            }
        }
        return listboxes;
    }
}
