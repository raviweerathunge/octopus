package com.matrix.octopus;

import com.matrix.octopus.octo.OctoDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.util.*;

/**
 * Created by raviw on 11/2/2017.
 */
public class FileParser {

    private SortedMap<String, TagInfo> taglist = new TreeMap<String, TagInfo>();
    private DocumentBuilderFactory dbFactory;
    private DocumentBuilder dBuilder;
    private static Logger logger = LoggerFactory.getLogger(FileParser.class);

    public FileParser() {
        dbFactory = DocumentBuilderFactory.newInstance();
        try {
            dBuilder = dbFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
    }

    public void init() {
        /// Move the taglist to XML in the future
        addTagInfo("Revenue AUD Mil" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Revenue NZD Mil" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Gross Margin %" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Net Income" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Earnings Per Share" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Dividends" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Book Value Per Share" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Working Capital" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("R&D" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Return on Assets" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Return on Equity" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Return on Invested Capital" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Interest Coverage" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Current Ratio" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Quick Ratio" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Financial Leverage (Average)" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Debt/Equity" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
        addTagInfo("Shares Mil" , OctoDefs.OCTO_DEFAULT_TAG_COUNT);
    }

    private void addTagInfo(String tag , int count) {
        TagInfo tagInfo = new TagInfo(tag , count);
        taglist.put(tag , tagInfo);
    }

    public Parameters parseratiofile(String folder , String filename) {

        String outpath = folder + "/" + filename;
        String line = "";

        Parameters params = new Parameters();
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(new File(outpath)))){
            while ((line = bufferedReader.readLine()) != null) {
                List<String> result = CSVUtils.parseLine(line);

                if (result.size() > 1) {
                    String keyvalue = result.get(0);
                    TagInfo taginfo = isTagListValue(keyvalue);
                    if (taginfo != null){
                        // This is inside our requirement list. Need to parse and get the value.
                        result.remove(0);
                        Parameter param = new Parameter();
                        param.set_name(taginfo.get_name());
                        param.set_tagInfo(taginfo);
                        param.parseValues(result);
                        params.addParameter(taginfo.get_name() , param);
                    }
                }
            }
        }catch (IOException e) {
            e.printStackTrace();
        } finally {
        }

        return params;
    }

    public ArrayList<PriceInfo> parseInvestoPediaFile(String outfolder , String outfilename) throws IOException, SAXException {
        String outpath = outfolder + "/" + outfilename;
        ArrayList<PriceInfo> pricelist = new ArrayList<PriceInfo>();

        File inputFile = new File(outpath);
        Document doc = dBuilder.parse(inputFile);
        doc.getDocumentElement().normalize();

        NodeList nList = doc.getElementsByTagName("tr");

        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element rootElement = (Element) nNode;

                if (rootElement.getAttribute("class").compareToIgnoreCase("in-the-money") == 0) {

                    PriceInfo priceinfo = new PriceInfo();

                    NodeList children = nNode.getChildNodes();
                    int count = 0;
                    boolean valid = true;
                    for (int j = 0; j < children.getLength(); j++) {
                        Node childNode = children.item(j);

                        if (childNode.getNodeType() == Node.ELEMENT_NODE) {
                            Element eElement = (Element) childNode;
                            if (eElement.getAttribute("class").compareToIgnoreCase("date") == 0) {
                                priceinfo.setDate("MMMM d, yyyy" , eElement.getTextContent());
                                count++;
                            }
                            else if (eElement.getAttribute("class").compareToIgnoreCase("num") == 0) {
                                if (count == 1) {
                                    priceinfo.setPrice(3,Double.parseDouble(eElement.getTextContent()));
                                    count++;
                                }
                                else if (count == 2) {
                                    priceinfo.setPrice(1,Double.parseDouble(eElement.getTextContent()));
                                    count++;
                                }
                                else if (count == 3) {
                                    priceinfo.setPrice(2,Double.parseDouble(eElement.getTextContent()));
                                    count++;
                                }
                                else if (count == 4) {
                                    priceinfo.setPrice(0,Double.parseDouble(eElement.getTextContent()));
                                    count++;
                                }
                                else if (count == 5) {
                                    String temp1 = eElement.getTextContent();
                                    priceinfo.setVolume(Double.parseDouble(eElement.getTextContent().replace(",","")));
                                    count++;
                                }
                            }
                            else if (eElement.getAttribute("class").compareToIgnoreCase("text") == 0) {
                                valid = false;
                                break;
                            }
                        }
                    }

                    if (valid == true)
                        pricelist.add(priceinfo);
                }
            }
        }
        return pricelist;
    }

    public TagInfo isTagListValue(String text) {

        for (Map.Entry<String, TagInfo> entry : taglist.entrySet()) {
            String tag = entry.getKey();

            if (text.indexOf(tag) == 0)
                return entry.getValue();
        }

       return null;
    }
}
