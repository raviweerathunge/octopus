package com.matrix.octopus.octo;

import com.matrix.octopus.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static java.time.temporal.ChronoUnit.DAYS;

/**
 * Created by raviw on 11/2/2017.
 */
@Component
@EnableConfigurationProperties
public class Octopus implements CommandLineRunner {

    private InstrumentLoader instrumentLoader;
    private OctoDBHandler dbHandler;
    private FileHandler filehandler;
    private FileParser fileparser;
    private Registry registry;
    private OctoConfigs octoConfigs;

    public static OctoFactory octofactory = new OctoFactory();

    private boolean processing = true;
    ArrayList<Thread> threads = new ArrayList<Thread>();

    private static Logger logger = LoggerFactory.getLogger(Octopus.class);

    @Autowired
    public Octopus(OctoConfigs octoConfigs , InstrumentLoader loader , OctoDBHandler dbHandler ,  FileHandler handler , FileParser parser , Registry cpuRegister) {
        this.instrumentLoader = loader;
        this.filehandler = handler;
        this.fileparser = parser;
        this.registry = cpuRegister;
        this.dbHandler = dbHandler;
        this.octoConfigs = octoConfigs;
    }

    @Override
    public void run(String... args) throws Exception {
        startProcessing();
    }

    private boolean startProcessing() throws InterruptedException, IOException, SAXException {

        String line = "";
        Instrument instrument = null;

        String regfolder = octoConfigs.getAffinityFilePath();
        boolean regload = registry.loadRegistryEntries(regfolder);
        if (regload == false) {
            logger.debug("error loading registry");
            return false;
        }

        fileparser.init();
        boolean insresult = instrumentLoader.loadInstrument(octoConfigs.getInstrumentFilePath());

        if (insresult == true)
        {
            ConcurrentHashMap<String, Instrument> instrumentlist = instrumentLoader.getInstruments();
            ArrayList<String> delistedinstruments = new ArrayList<>();
            for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet())  {
                line = entry.getKey();
                instrument = entry.getValue();
                logger.debug("reading instrunment - {}",line);

                boolean result = false;
                String folder = octoConfigs.getFinancialOutFolder() + octoConfigs.getExchangeCode() + "/" + line;
                String bbfolder = octoConfigs.getBlackBoxOutFolder() +  octoConfigs.getExchangeCode();
                File theDir = new File(folder);
                if (!theDir.exists()) {
                    logger.debug("creating directory: {}" , theDir.getName());
                    try {
                        theDir.mkdir();
                        result = true;
                    } catch (SecurityException se) {
                        logger.debug("error creating directory: {}",theDir.getName());
                    }
                } else {
                    result = true;
                }

                theDir = new File(bbfolder);
                if (!theDir.exists()) {
                    try {
                        theDir.mkdir();
                        logger.debug("creating blackbox directory: {}" , theDir.getName());
                    } catch (SecurityException se) {
                        logger.debug("error creating blackbox directory: {}" ,theDir.getName());
                    }
                }

                if (result == true){
                    ////
                    String urlpath = String.format("http://financials.morningstar.com/ajax/exportKR2CSV.html?t=%s:%s" , octoConfigs.getExchangeCode() , line);
                    String filename = line + octoConfigs.getRatioFileNamePrefix();
                    if (!filehandler.fileExists(folder , filename) || octoConfigs.getFileOwerite())
                        filehandler.downloadFile(urlpath , folder , filename);

                    urlpath = String.format("http://financials.morningstar.com/ajax/ReportProcess4CSV.html?t=%s:%s&reportType=is&period=12&dataType=A&order=asc&columnYear=5&number=3", octoConfigs.getExchangeCode() , line);
                    filename = line + octoConfigs.getIncomeStatementFileNamePrefix();
                    if (!filehandler.fileExists(folder , filename) || octoConfigs.getFileOwerite())
                        filehandler.downloadFile(urlpath , folder , filename);

                    urlpath = String.format("http://financials.morningstar.com/ajax/ReportProcess4CSV.html?t=%s:%s&reportType=cf&period=12&dataType=A&order=asc&columnYear=5&number=3", octoConfigs.getExchangeCode() , line);
                    filename = line + octoConfigs.getCashFlowStatementFileNamePrefix();
                    if (!filehandler.fileExists(folder , filename) || octoConfigs.getFileOwerite())
                        filehandler.downloadFile(urlpath , folder , filename);

                    urlpath = String.format("http://financials.morningstar.com/ajax/ReportProcess4CSV.html?t=%s:%s&reportType=bs&period=12&dataType=A&order=asc&columnYear=5&number=3", octoConfigs.getExchangeCode() , line);
                    filename = line + octoConfigs.getBalanceSheetStatementFileNamePrefix();
                    if (!filehandler.fileExists(folder , filename) || octoConfigs.getFileOwerite())
                        filehandler.downloadFile(urlpath , folder , filename);

                    /// New SQLite3 Database Support
                    try {
                        ArrayList<PriceInfo> priceInfo = downloadPriceData(line , folder);
                        instrument.set_pricelist(priceInfo);
                        logger.debug("price history array size - {}" ,String.valueOf(priceInfo.size()));
                    } catch (SQLException e) {
                        logger.error("error downloading price data for symbol - {}" , line);
                        ArrayList<PriceInfo> pricelist = new ArrayList<>();
                        instrument.set_pricelist(pricelist);
                        delistedinstruments.add(line);
                    }
                    /// New SQLite3 Database Support
                }
                System.out.print("\n");
            }

            /// Remove delisted instruments
            int removecount = delistedinstruments.size();
            for(int i=0;i<removecount;i++) {
                String instrumentname = delistedinstruments.get(i);
                instrumentLoader.removeInstrument(instrumentname);

                // Remove instrument folder
                String folder = octoConfigs.getFinancialOutFolder() + octoConfigs.getExchangeCode() + "/" + instrumentname;

                File file = new File(folder);
                OctoUtils.deleteDirectory(file);
            }

            instrumentLoader.writeValidInstruments(octoConfigs.getInstrumentFilePath());

            scanParameters();
            startCPUs();
        }
        else
            logger.debug("error reading file - " + octoConfigs.getInstrumentFilePath());

        return insresult;
    }

    private void scanParameters() {
        String line = "";
        Instrument inst = null;
        ConcurrentHashMap<String, Instrument> instrumentlist = instrumentLoader.getInstruments();
        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            line = entry.getKey();
            inst = entry.getValue();
            logger.debug("scanning instrument details - {}", line);
            String filename = line + octoConfigs.getRatioFileNamePrefix();
            String folder = octoConfigs.getFinancialOutFolder() + octoConfigs.getExchangeCode() + "/" +  line;
            Parameters params = fileparser.parseratiofile(folder , filename);
            if (params != null) {
                inst.set_parameter(params);
            }
        }
    }

    private void startCPUs() throws InterruptedException {
        ExecutorService executor = Executors.newFixedThreadPool(octoConfigs.getCpuCount());

        for (int i=0 ; i < octoConfigs.getCpuCount() ; i++) {
            executor.execute(new OctoCPU(i , instrumentLoader , registry));
        }

        executor.shutdown();
        executor.awaitTermination(Long.MAX_VALUE, TimeUnit.MINUTES);
        logger.debug("all cpus completed processing");
    }

    private ArrayList<PriceInfo> downloadPriceData(String symbol , String folder) throws IOException, SAXException, SQLException {
        int rowcount = 0;
        try {
            rowcount = dbHandler.getTableRowCount(symbol);
        } catch (SQLException e) {
            try {
                dbHandler.createPriceTable(symbol);
            } catch (SQLException j) {
                throw new SQLException(j);
            }
        }

        if (rowcount == 0) {
            LocalDate date = LocalDate.now();
            LocalDate olddate = date.minusYears(OctoDefs.OCTO_HISTORY_DATA_YEARS);

            String urlpath = String.format("https://www.investopedia.com/markets/api/partial/historical/?Symbol=%s.%s&Type=Historical+Prices&Timeframe=Daily&StartDate=%s+%d%%2C+%d&EndDate=%s+%d%%2C+%d" , symbol , octoConfigs.getExchangeCode() , olddate.getMonth().getDisplayName(TextStyle.SHORT,Locale.ENGLISH) , olddate.getDayOfMonth() , olddate.getYear() , date.getMonth().getDisplayName(TextStyle.SHORT,Locale.ENGLISH) , date.getDayOfMonth() , date.getYear());
            String filename = symbol + octoConfigs.getPriceFileNamePrefix();
            boolean downloaded = false;
            if (filehandler.downloadFile(urlpath, folder, filename)) {
                downloaded = true;
            }

            if (downloaded) {
                ArrayList<PriceInfo> pricelist = fileparser.parseInvestoPediaFile(folder, filename);
                if (pricelist.size() == 0) {
                    dbHandler.dropTable(symbol);
                    throw new SQLException("no data available for the symbol - {}" , symbol);
                }
                else {
                    dbHandler.addBulkPriceDataInfo(symbol, pricelist);
                }
            }
            else {
                logger.error("error downloading price data for symbol - {}" , symbol);
                dbHandler.dropTable(symbol);
                throw new SQLException("error downloading price data for symbol - {}" , symbol);
            }
        }
        else {
            PriceInfo info = dbHandler.getLatest(symbol);
            String lastDate = info.getDateString("yyyy-MM-dd");

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            LocalDate today = LocalDate.now();
            LocalDate lastDateValue = LocalDate.parse(lastDate, formatter);

            long daysBetween = DAYS.between(lastDateValue , today);
            if (daysBetween > 2) {
                LocalDate date = today;

                String urlpath = String.format("https://www.investopedia.com/markets/api/partial/historical/?Symbol=%s.%s&Type=Historical+Prices&Timeframe=Daily&StartDate=%s+%d%%2C+%d&EndDate=%s+%d%%2C+%d" , symbol , octoConfigs.getExchangeCode() , lastDateValue.getMonth().getDisplayName(TextStyle.SHORT,Locale.ENGLISH) , lastDateValue.getDayOfMonth() , lastDateValue.getYear() , date.getMonth().getDisplayName(TextStyle.SHORT,Locale.ENGLISH) , date.getDayOfMonth() , date.getYear());
                String filename = symbol + octoConfigs.getPriceFileNamePrefix();
                boolean ret = filehandler.downloadFile(urlpath, folder, filename);
                if (ret) {
                    ArrayList<PriceInfo> arrlist = fileparser.parseInvestoPediaFile(folder, filename);
                    dbHandler.addBulkPriceDataInfo(symbol, arrlist);

                    ///
                    info = dbHandler.getLatest(symbol);
                    lastDate = info.getDateString("yyyy-MM-dd");

                    formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

                    today = LocalDate.now();
                    lastDateValue = LocalDate.parse(lastDate, formatter);

                    daysBetween = DAYS.between(lastDateValue , today);
                    if (daysBetween > 10) {
                        dbHandler.dropTable(symbol);
                        throw new SQLException("no valid history data available for the symbol - {}" , symbol);
                    }
                    ///
                }
            }
        }

        ArrayList<PriceInfo> instrumentData = dbHandler.getPriceTableData(symbol);
        return instrumentData;
    }

}
