package com.matrix.octopus.octo;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
@Configuration
@ConfigurationProperties(prefix="octopus")
public class OctoConfigs {
    @Getter
    @Setter
    public String instrumentFilePath;

    @Getter
    @Setter
    public String ratioFileNamePrefix;

    @Getter
    @Setter
    public String incomeStatementFileNamePrefix;

    @Getter
    @Setter
    public String cashFlowStatementFileNamePrefix;

    @Getter
    @Setter
    public String balanceSheetStatementFileNamePrefix;

    @Getter
    @Setter
    public String priceFileNamePrefix;

    @Getter
    @Setter
    public String financialOutFolder;

    @Getter
    @Setter
    public String affinityFilePath;

    @Getter
    @Setter
    public Boolean fileOwerite;

    @Getter
    @Setter
    public int cpuCount;

    @Getter
    @Setter
    public String blackBoxOutFolder;

    @Getter
    @Setter
    public String exchangeCode;

    public OctoConfigs() {

    }
}
