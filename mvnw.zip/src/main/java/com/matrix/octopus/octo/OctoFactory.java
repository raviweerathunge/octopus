package com.matrix.octopus.octo;

import com.matrix.octopus.InstrumentLoader;
import com.matrix.octopus.RegistryEntry;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.blackbox.*;

/**
 * Created by raviw on 11/13/2017.
 */
public class OctoFactory {
    public synchronized OctoBaseBox createBlackBox(OctoConfigs octoConfigs ,RegistryEntry regentry , InstrumentLoader loader) {

        OctoBaseBox bb = null;

        String name = regentry.getItemname();
        switch (name) {
            case OctoDefs.OCTO_BB_ROIC:
                bb = new BBROIC();
                break;
            case OctoDefs.OCTO_BB_DEBT_TO_EQUITY:
                bb = new BBDebtToEquity();
                break;
            case OctoDefs.OCTO_BB_ROE:
                bb = new BBROE();
                break;
            case OctoDefs.OCTO_BB_QUICK_RATION:
                bb = new BBQuickRatio();
                break;
            case OctoDefs.OCTO_BB_DIVIDEND_GROWTH:
                bb = new BBDividendGrowth();
                break;
            case OctoDefs.OCTO_BB_PE_SECTOR:
                bb = new BBPESector();
                break;
            case OctoDefs.OCTO_BB_PB:
                bb = new BBPriceToBook();
                break;
            case OctoDefs.OCTO_BB_STDDEVIATION:
                bb = new BBStdDeviation();
                break;
            case OctoDefs.OCTO_BB_INTEREST_COVERAGE:
                bb = new BBInterestCoverage();
                break;
            case OctoDefs.OCTO_BB_PEXPB:
                bb = new BBPExPB();
                break;
            case OctoDefs.OCTO_BB_GRAHAM:
                bb = new BBGraham();
                break;
            case OctoDefs.OCTO_BB_PE:
                bb = new BBPE();
                break;
            case OctoDefs.OCTO_BB_PEG:
                bb = new BBPEG();
                break;
            case OctoDefs.OCTO_BB_GROWTH_TO_EARNINGS:
                bb = new BBGrowthToEarnings();
                break;
            case OctoDefs.OCTO_BB_CORRELATION:
                bb = new BBCorrelation();
                break;
            case OctoDefs.OCTO_BB_DUAL_MOMENTUM:
                bb = new BBDualMomentum();
                break;
            default:
                throw new IllegalArgumentException("Black box name - " + name);
        }

        if (bb != null)
            bb.init(octoConfigs , regentry , loader);

        return bb;
    }
}
