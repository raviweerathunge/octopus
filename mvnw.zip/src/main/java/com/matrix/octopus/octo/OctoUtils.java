package com.matrix.octopus.octo;

import java.io.File;

/**
 * Created by raviw on 11/28/2017.
 */
public class OctoUtils {

    static boolean deleteDirectory(File directoryToBeDeleted) {
        File[] allContents = directoryToBeDeleted.listFiles();
        if (allContents != null) {
            for (File file : allContents) deleteDirectory(file);
        }
        return directoryToBeDeleted.delete();
    }
}
