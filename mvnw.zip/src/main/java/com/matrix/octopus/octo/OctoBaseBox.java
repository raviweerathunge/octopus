package com.matrix.octopus.octo;

import com.matrix.octopus.*;

import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 11/14/2017.
 */
public class OctoBaseBox implements OctoBlackBox {

    // OctoBlackBox interface override methods
    public void init(OctoConfigs configs ,RegistryEntry regentry , InstrumentLoader loader) {
        registryentry = regentry;
        instrumentLoader = loader;
        octoConfigs = configs;
    }
    public void start() {
        String filename = registryentry.getItemname() + "_" + String.valueOf(registryentry.getItemcpu()) + ".txt";

        String folder = octoConfigs.getBlackBoxOutFolder() +  octoConfigs.getExchangeCode();
        openblackboxfile(octoConfigs.getBlackBoxOutFolder() +  octoConfigs.getExchangeCode() + "/" + filename);
    }
    public void process(ConcurrentHashMap<String, Instrument> filteredlist) throws OctoException {}
    public void stop() {
        closeblackboxfile();
    }
    public void cleanup() {}
    public int getProgress() {
        return 0;
    }
    public String getName() {
        return registryentry.getItemname();
    }
    public int getID() {
        return registryentry.getItemid();
    }

    // File output methods.
    public boolean openblackboxfile(String filename) {
        try {
            writer = Files.newBufferedWriter(Paths.get(filename), StandardCharsets.UTF_8);
        }
        catch (Exception e) {
            return false;
        }
        return true;
    }

    public boolean closeblackboxfile() {
        try {
            if (writer != null)
                writer.close();
        }
        catch (Exception e) {
            return false;
        }

        return true;
    }

    public boolean writeblackboxfile(String line) {
        try {
            if (writer != null) {
                writer.write(line);
                writer.newLine();
            }
        }
        catch (Exception e) {
            return false;
        }

        return true;
    }

    public void addFilteredInstrument(String name , Instrument instrument) {
        filteredinstruments.put(name , instrument);
    }

    public ConcurrentHashMap<String, Instrument> getFilteredinstruments() {
        return filteredinstruments;
    }

    public void clearFilteredInstruments() {
        filteredinstruments.clear();
    }

    public String getParentBox() {
        return registryentry.getParentName();
    }

    public OctoUtils getOctoUtils() {
        return octoUtils;
    }

    protected RegistryEntry registryentry = null;
    protected InstrumentLoader instrumentLoader = null;
    protected BufferedWriter writer = null;

    protected ConcurrentHashMap<String, Instrument> filteredinstruments = new ConcurrentHashMap<String, Instrument>();

    protected OctoUtils octoUtils = new OctoUtils();
    protected OctoConfigs octoConfigs;
}
