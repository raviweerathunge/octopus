package com.matrix.octopus.octo;

/**
 * Created by raviw on 11/2/2017.
 */
public class OctoDefs {

    // Black boxes
    public static final String OCTO_BB_ROIC = "ROIC";
    public static final String OCTO_BB_DEBT_TO_EQUITY = "DEBTTOEQUITY";
    public static final String OCTO_BB_ROE = "ROE";
    public static final String OCTO_BB_QUICK_RATION = "QUICKRATIO";
    public static final String OCTO_BB_DIVIDEND_GROWTH = "DIVIDENDGROWTH";
    public static final String OCTO_BB_PE_SECTOR = "PESECTOR";
    public static final String OCTO_BB_PB = "PRICETOBOOK";
    public static final String OCTO_BB_STDDEVIATION = "STDDEVIATION";
    public static final String OCTO_BB_INTEREST_COVERAGE = "INTERESTCOVERAGE";
    public static final String OCTO_BB_PEXPB = "PExPB";
    public static final String OCTO_BB_GRAHAM = "GRAHAM";
    public static final String OCTO_BB_PE = "PE";
    public static final String OCTO_BB_PEG = "PEG";
    public static final String OCTO_BB_GROWTH_TO_EARNINGS = "GROWTHTOEARNINGS";
    public static final String OCTO_BB_CORRELATION = "CORRELATIONS";
    public static final String OCTO_BB_DUAL_MOMENTUM = "DUALMOMENTUM";

    public static final int OCTO_HISTORY_DATA_YEARS = 1;
    public static final int OCTO_DEFAULT_TAG_COUNT = 11;

    public static final Double OCTO_10_YEAR_AAA_BOND_RATE = 2.539;
    public static final Double OCTO_15_YEAR_AAA_BOND_RATE = 2.812;
    public static final Double OCTO_20_YEAR_AAA_BOND_RATE = 3.014;
    public static final Double OCTO_30_YEAR_AAA_BOND_RATE = 3.266;
}
