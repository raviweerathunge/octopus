package com.matrix.octopus;

/**
 * Created by raviw on 11/8/2017.
 */
public class Logger {
    public static void init(int logLevel) {
        m_logLevel = logLevel;
    }

    public synchronized static void logDebug(String text , int level) {
        if (level >= m_logLevel)
            System.out.println(text);
    }

    private static int m_logLevel;
}
