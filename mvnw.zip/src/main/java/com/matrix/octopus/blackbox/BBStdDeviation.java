package com.matrix.octopus.blackbox;

import com.matrix.octopus.Instrument;
import com.matrix.octopus.Parameter;
import com.matrix.octopus.Parameters;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;
import com.matrix.octopus.octo.OctoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 11/20/2017.
 */
public class BBStdDeviation extends OctoBaseBox {

    private static Logger logger = LoggerFactory.getLogger(BBStdDeviation.class);

    @Override
    public void process(ConcurrentHashMap<String, Instrument> filteredlist) throws OctoException {
        clearFilteredInstruments();

        ConcurrentHashMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        writeblackboxfile("UPPER/LOWER" + "," + "INSTRUMENT" + "," + "CLOSEPRICE" +  "," + "MEAN" + "," + "STD" + "," + "BOOKVALUE" + "," + "EARNINGS" + "," + "SECTOR");

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);

            Double mean = instemp.getMean();
            Double std = instemp.getStd();

            Double plusstd = mean + registryentry.getParameterValueInt(0) * std;
            Double minusstd = mean - registryentry.getParameterValueInt(0) * std;

            if (instemp.getlatestpriceinfo() != null) {
                Double closeprice = instemp.getlatestpriceinfo().getClose();
                Parameters params = instemp.accquire_parameter();
                if (closeprice > plusstd || closeprice < minusstd) {

                    Double bookvalue = 0.0;
                    Double earnings = 0.0;

                    if (closeprice > plusstd) {
                        if (params != null) {
                            Parameter parameter = params.getParameter("Book Value Per Share");
                            if (parameter != null)
                                bookvalue = parameter.getAverage();
                            parameter = params.getParameter("Earnings Per Share");
                            if (parameter != null)
                                earnings = parameter.getAverage();
                        }

                        logger.debug("upper " + instrument + " - is : " + closeprice + " Mean:" + mean + " Std " + std + " Book Value: " + bookvalue);
                        writeblackboxfile("upper" + "," + instrument + "," + closeprice +  "," + mean + "," + std + "," + bookvalue + "," + earnings + "," + instemp.get_sector());
                    }
                    else {
                        if (params != null) {
                            Parameter parameter = params.getParameter("Book Value Per Share");
                            if (parameter != null)
                                bookvalue = parameter.getAverage();
                            parameter = params.getParameter("Earnings Per Share");
                            if (parameter != null)
                                earnings = parameter.getAverage();
                        }

                        logger.debug("lower " + instrument + " - is : " + closeprice + " Mean:" + mean + " Std " + std + " Book Value: " + bookvalue);
                        writeblackboxfile("lower" + "," + instrument + "," + closeprice +  "," + mean + "," + std + "," + bookvalue + "," + earnings + "," + instemp.get_sector());
                        addFilteredInstrument(instrument , instemp);
                    }
                }
                instemp.release_parameter();
            }
        }
    }
}
