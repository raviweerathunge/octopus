package com.matrix.octopus.blackbox;

import com.matrix.octopus.*;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;
import com.matrix.octopus.octo.OctoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;

import static com.matrix.octopus.octo.OctoDefs.OCTO_DEFAULT_TAG_COUNT;

/**
 * Created by raviw on 12/11/2017.
 */
public class BBPEG extends OctoBaseBox {
    private static Logger logger = LoggerFactory.getLogger(BBPEG.class);


    @Override
    public void process(ConcurrentHashMap<String, Instrument> filteredlist) throws OctoException {
        clearFilteredInstruments();

        ConcurrentHashMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        writeblackboxfile("INSTRUMENT" + "," + "DESCRIPTION" + "," + "MARKET CAPITALIZATION" + "," + "PEG");

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameterEarnings = params.getParameter("Earnings Per Share");
                Parameter parameterCapital = params.getParameter("Shares Mil");

                if (parameterEarnings != null && parameterEarnings.getSize() > registryentry.getParameterValueInt(0)) {

                    int size = parameterEarnings.getSize();

                    Double last = parameterEarnings.getValue(registryentry.getParameterValueInt(1));
                    Double previous = parameterEarnings.getValue(registryentry.getParameterValueInt(2));

                    if (last.isNaN() == false && previous.isNaN() == false) {
                        PriceInfo priceInfo = instemp.getlatestpriceinfo();
                        if (priceInfo != null) {

                            Double peRatio = priceInfo.getClose() / last;
                            Double growth = ((last - previous) / previous) * 100;

                            if (growth != 0.0 && growth.isNaN() == false && peRatio.isNaN() == false) {
                                Double pegValue = peRatio / growth;

                                Double mktCapital = 0.0;
                                if (parameterCapital != null && parameterCapital.getLatest().isNaN() == false)
                                    mktCapital = parameterCapital.getLatest() * priceInfo.getClose();
                                if (pegValue > registryentry.getParameterValueDouble(3) && pegValue <= registryentry.getParameterValueDouble(4)) {
                                    logger.debug("printing price / earnings history for {} is:{}" ,instrument , peRatio);
                                    writeblackboxfile(instrument + "," + instemp.get_instrumentdescription() + "," + mktCapital + "," + pegValue);
                                    addFilteredInstrument(instrument, instemp);
                                }
                            }
                        }
                    }
                }
            }
            instemp.release_parameter();
        }
    }
}
