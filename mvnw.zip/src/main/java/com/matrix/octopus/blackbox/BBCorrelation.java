package com.matrix.octopus.blackbox;

import com.matrix.octopus.Instrument;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoException;
import org.ojalgo.finance.data.YahooSymbol;
import org.ojalgo.random.SampleSet;
import org.ojalgo.series.CalendarDateSeries;
import org.ojalgo.series.CoordinationSet;
import org.ojalgo.series.primitive.DataSeries;
import org.ojalgo.type.CalendarDateUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class BBCorrelation extends OctoBaseBox {
    private static Logger logger = LoggerFactory.getLogger(BBCorrelation.class);
    private Set<String> valid = new HashSet<>();

    @Override
    public void process(ConcurrentHashMap<String, Instrument> filteredlist) throws OctoException {
        clearFilteredInstruments();
        valid.clear();

        ConcurrentHashMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String id = entry.getKey();
            Instrument ins = entry.getValue();

            if (ins.getMktCap() < registryentry.getParameterValueInt(0))
                continue;

            checkC(id , entry.getValue());
        }
    }

    public void checkC(String id , Instrument insInitial) {
        ConcurrentHashMap<String, Instrument> instrumentlist = instrumentLoader.getInstruments();

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String symbol = entry.getKey();

            if (symbol == id)
                continue;

            if (valid.contains(symbol)) {
                continue;
            }

            Instrument ins1 = insInitial;
            Instrument ins2 = entry.getValue();

            if (ins1.get_sector().equals(ins2.get_sector()) == false)
                continue;

            CalendarDateSeries<Double> tmp1 = ins1.getCalendarDateSeries();
            CalendarDateSeries<Double> tmp2= ins2.getCalendarDateSeries();

            CoordinationSet<Double> tmpUncoordinated = new CoordinationSet<>();
            tmpUncoordinated.put(id, tmp1);
            tmpUncoordinated.put(symbol, tmp2);

            try {
                CoordinationSet<Double> tmpCoordinated = tmpUncoordinated.prune(CalendarDateUnit.MONTH);

                DataSeries tmpMonthly1 = tmpCoordinated.get(id).getDataSeries();
                DataSeries tmpMonthly2 = tmpCoordinated.get(symbol).getDataSeries();

                SampleSet tmpsample1 = SampleSet.wrap(tmpMonthly1.log().differences());
                SampleSet tmpsample2 = SampleSet.wrap(tmpMonthly2.log().differences());

                Double correlation = tmpsample1.getCorrelation(tmpsample2);
                if (correlation > registryentry.getParameterValueDouble(1) || correlation < registryentry.getParameterValueDouble(2)) {
                    logger.debug("Correlation: {} vs {} is : {}", id, symbol, correlation);
                    writeblackboxfile("Correlation: Instrument - " + id + " " + "Instrument - " + symbol + " " + "Correlation : " + correlation);
                }
            } catch (Exception e) {
                logger.error("error calculating correlation for : {} - {}" , id , symbol);
            }
        }

        valid.add(id);
    }
}
