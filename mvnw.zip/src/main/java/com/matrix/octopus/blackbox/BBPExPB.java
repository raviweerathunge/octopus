package com.matrix.octopus.blackbox;

import com.matrix.octopus.*;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;
import com.matrix.octopus.octo.OctoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 11/22/2017.
 */
public class BBPExPB extends OctoBaseBox {

    private static Logger logger = LoggerFactory.getLogger(BBPExPB.class);

    @Override
    public void process(ConcurrentHashMap<String, Instrument> filteredlist) throws OctoException {
        clearFilteredInstruments();

        ConcurrentHashMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameterBook = params.getParameter("Book Value Per Share");
                Parameter parameterEarnings = params.getParameter("Earnings Per Share");

                if (parameterBook != null && parameterEarnings != null && parameterBook.getLatest().isNaN() == false && parameterBook.getLatest() != 0.0 &&
                        parameterEarnings.getLatest().isNaN() == false && parameterEarnings.getLatest() != 0.0) {
                    PriceInfo priceInfo = instemp.getlatestpriceinfo();
                    if (priceInfo != null) {
                        Double pbRatio = priceInfo.getClose() / parameterBook.getLatest();
                        Double peRatio = priceInfo.getClose() / parameterEarnings.getLatest();

                        if ((pbRatio * peRatio) > 0 && (pbRatio * peRatio) < registryentry.getParameterValueInt(0) && pbRatio <= registryentry.getParameterValueDouble(1)) {
                            logger.debug("PExPB {} is : {}" , instrument , pbRatio * peRatio);
                            writeblackboxfile(instrument + "," + pbRatio * peRatio);
                            addFilteredInstrument(instrument, instemp);
                        }
                    }
                }
            }
            instemp.release_parameter();
        }
    }
}
