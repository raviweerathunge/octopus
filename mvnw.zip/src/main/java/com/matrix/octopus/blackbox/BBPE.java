package com.matrix.octopus.blackbox;

import com.matrix.octopus.*;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;
import com.matrix.octopus.octo.OctoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 12/11/2017.
 */
public class BBPE extends OctoBaseBox {

    private static Logger logger = LoggerFactory.getLogger(BBPE.class);

    @Override
    public void process(ConcurrentHashMap<String, Instrument> filteredlist) throws OctoException {
        clearFilteredInstruments();

        ConcurrentHashMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        writeblackboxfile("INSTRUMENT" + "," + "DESCRIPTION" + "," + "PE");


        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameterEarnings = params.getParameter("Earnings Per Share");
                Parameter parameterCapital = params.getParameter("Shares Mil");

                if (parameterEarnings != null && parameterEarnings.getLatest().isNaN() == false && parameterEarnings.getLatest() > 0) {
                    PriceInfo priceInfo = instemp.getlatestpriceinfo();
                    if (priceInfo != null) {
                        Double peRatio = priceInfo.getClose() / parameterEarnings.getLatest();
                        if (parameterCapital != null)

                        if (peRatio > registryentry.getParameterValueInt(0) && peRatio < registryentry.getParameterValueInt(1)) {
                            logger.debug("printing price / earnings history for " + instrument + " - is : " + peRatio);
                            writeblackboxfile(instrument + "," + instemp.get_instrumentdescription() + "," + peRatio);
                            addFilteredInstrument(instrument, instemp);
                        }
                    }
                }
            }
            instemp.release_parameter();
        }
    }
}
