package com.matrix.octopus.blackbox;

import com.matrix.octopus.*;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 12/8/2017.
 */
public class BBGraham extends OctoBaseBox {

    private static Logger logger = LoggerFactory.getLogger(BBGraham.class);

    public void process(ConcurrentHashMap<String, Instrument> filteredlist) {
        clearFilteredInstruments();

        ConcurrentHashMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameter = params.getParameter("Earnings Per Share");
                if (parameter != null && parameter.getLatest().isNaN() == false) {

                    PriceInfo priceInfo = instemp.getlatestpriceinfo();

                    if (priceInfo != null) {
                        Double earnings = parameter.getLatest();
                        Double mean = parameter.getAverage();
                        Double latest = parameter.getLatest();

                        if (earnings > 0 && mean > 0 && latest > 0) {
                            Double growth = ((latest - mean) / mean) * 100;
                            if (growth > 0) {
                                Double value = (earnings * (7 + 1.5 * growth) * 4.4) / OctoDefs.OCTO_20_YEAR_AAA_BOND_RATE;
                                Double price = priceInfo.getClose();

                                if (price < value) {
                                    logger.debug("Intrinsic vlaue is higher for " + instrument + " price: " + price + " intrinsic:" + value);
                                    writeblackboxfile(instrument + "," + price + "," + value);
                                    addFilteredInstrument(instrument, instemp);
                                }
                            }
                        }
                    }
                }
            }
            instemp.release_parameter();
        }
    }
}
