package com.matrix.octopus.blackbox;

import com.matrix.octopus.Instrument;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoException;
import org.ojalgo.series.CalendarDateSeries;
import org.ojalgo.series.primitive.ExplicitTimeSeries;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;

public class BBDualMomentum extends OctoBaseBox {
    private static Logger logger = LoggerFactory.getLogger(BBDualMomentum.class);

    @Override
    public void process(ConcurrentHashMap<String, Instrument> filteredlist) throws OctoException {
        clearFilteredInstruments();

        ConcurrentHashMap<String, Instrument> instrumentlist = instrumentLoader.getInstruments();

        writeblackboxfile("SYMBOL" + "," + "MOMENTUM" + "," + "SECTOR");

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String symbol = entry.getKey();
            Instrument instrument = entry.getValue();
            String sector = instrument.get_sector();

            CalendarDateSeries<Double> calendarDateSeries = instrument.getCalendarDateSeries();
            ExplicitTimeSeries explicitTimeSeries = calendarDateSeries.getPrimitiveTimeSeries();

            if (explicitTimeSeries.size() < registryentry.getParameterValueInt(0)) {
                continue;
            }

            Double d1 = (explicitTimeSeries.get(251) / explicitTimeSeries.get(registryentry.getParameterValueInt(1))) - 1;
            Double d3 = (explicitTimeSeries.get(251) / explicitTimeSeries.get(registryentry.getParameterValueInt(2))) - 1;
            Double d6 = (explicitTimeSeries.get(251) / explicitTimeSeries.get(registryentry.getParameterValueInt(3))) - 1;
            Double d12 = (explicitTimeSeries.get(251) / explicitTimeSeries.get(registryentry.getParameterValueInt(4))) - 1;

            Double score1 = d1 + d3 + d6;
            Double score2 = d3 + d6 + d12;

            Double average = (score1 + score2) / 2;

            if (average > 0.0) {
                writeblackboxfile(symbol + "," + average + "," + sector);
            }
        }
    }

}

/*
//Get best asset class within each subcategory
df = pd.DataFrame(columns=['Weight','Score1','Score2','1Year','6Mon','3Mon','1Mon'])
//Calculate Momentum Ratios
for stock in assets:
his = data.history(stock, "price", 252, frequency="1d")
df.loc[stock, '1Mon'] = his[-1] / his[-21] - 1
df.loc[stock, '3Mon'] = his[-1] / his[-63] - 1
df.loc[stock, '6Mon'] = his[-1] / his[-126] - 1
df.loc[stock, '1Year'] = his[-1] / his[0] - 1

//Check Term Trend is Positive
df = df.astype(float)
df['Score1'] = df['1Mon'] + df['3Mon'] + df['6Mon']
df['Score2'] = df['3Mon'] + df['6Mon'] + df['1Year']
df['Weight'] = df['Score1']
df.loc[df['Weight'] < 0, 'Weight'] = 0.0

//Set outofmarket, and allworld to 0
df.loc[context.world, 'Weight'] = 0.0
df.loc[context.outofmarket, 'Weight'] = 0.0
df.loc[context.midvalue, 'Weight'] = 0.0
df.loc[context.tips, 'Weight'] = 0.0

//Get only top assets
df.loc[~df.index.isin(df['Weight'].nlargest(MAX_ASSETS).index.tolist()),'Weight'] = 0.0
*/

