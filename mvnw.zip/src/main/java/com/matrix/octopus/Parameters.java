package com.matrix.octopus;

import java.util.SortedMap;
import java.util.TreeMap;

/**
 * Created by raviw on 11/7/2017.
 */
public class Parameters {
    private SortedMap<String, Parameter> params = new TreeMap<String, Parameter>();

    public SortedMap<String, Parameter> getParams() {
        return params;
    }

    public void addParameter(String name , Parameter param) {
        params.put(name , param);
    }

    public Parameter getParameter(String name) {
        return params.get(name);
    }
}
