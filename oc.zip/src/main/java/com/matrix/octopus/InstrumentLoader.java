package com.matrix.octopus;

import com.matrix.octopus.octo.OctoDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 11/2/2017.
 */
public class InstrumentLoader {
    private ConcurrentHashMap<String, Instrument> instruments = new ConcurrentHashMap<String, Instrument>();
    private static Logger logger = LoggerFactory.getLogger(InstrumentLoader.class);

    public ConcurrentHashMap<String, Instrument> getInstruments() {
        return instruments;
    }

    private boolean addInstrument(String id , String name , String sector){
        if (this.instruments.get(name) != null)
            return false;
        Instrument ins = new Instrument(id ,name , sector);
        this.instruments.put(id , ins);
        return true;
    }

    public synchronized boolean loadInstrument(String filename) {

        boolean result = false;
        int filecount = 0;
        String line = "";
        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(filename)))){
            while ((line = in.readLine()) != null) {
                List<String> instrumentdetails = CSVUtils.parseLine(line);
                if (instrumentdetails.size() == 3) {
                    logger.debug("reading instrunment - id - {}", instrumentdetails.get(0));
                    this.addInstrument(instrumentdetails.get(0) , instrumentdetails.get(1) , instrumentdetails.get(2));
                    filecount++;
                }
            }
            in.close();
            result = true;
            logger.debug("reading instrunments completed");
        } catch (IOException e) {
            e.printStackTrace();
            result = false;
        }
        logger.debug("total files read - {}" , filecount);
        return result;
    }

    public synchronized void writeValidInstruments(String filename) {
        try (FileWriter writer = new FileWriter(filename)){
            String line = "";
            Instrument inst = null;

            for (Map.Entry<String, Instrument> entry : instruments.entrySet()) {
                inst = entry.getValue();

                CSVUtils.writeLine(writer, Arrays.asList(inst.get_instrumentname(), inst.get_instrumentdescription(), inst.get_sector()));
            }

            writer.flush();
        }
        catch (Exception e) {
            e.printStackTrace();
            logger.debug("error saving valid instruments" + "\n");
        }
    }

    public synchronized Instrument findInstrument(String name) {
        return this.instruments.get(name);
    }

    public synchronized void removeInstrument(String name) {
        this.instruments.remove(name);
    }
}
