package com.matrix.octopus;

import com.matrix.octopus.octo.OctoFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.io.File;

@Component
public class ComponentHelper {

    @Bean
    public InstrumentLoader getInstrumentLoader() {
        return new InstrumentLoader();
    }

    @Bean
    public FileHandler getFilehandler() {
        return new FileHandler();
    }

    @Bean
    public FileParser getFileparser() {
        return new FileParser();
    }

    @Bean
    public OctoFactory getOctoBBFactory() {
        return new OctoFactory();
    }

}
