package com.matrix.octopus;

import com.matrix.octopus.octo.OctoDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by raviw on 10/28/2017.
 */
public class FileHandler {

    private static Logger logger = LoggerFactory.getLogger(FileHandler.class);

    public boolean downloadFile(String urlpath, String outfolder, String outfilename) {
        boolean result = false;
        BufferedReader bufferedReader = null;
        try {
            URL url = new URL(urlpath);
            URLConnection urlConn = url.openConnection();
            InputStreamReader inputStreamReader = new InputStreamReader(urlConn.getInputStream());
            bufferedReader = new BufferedReader(inputStreamReader);
            String outpath = outfolder + "/" + outfilename;
            BufferedWriter writer = Files.newBufferedWriter(Paths.get(outpath), StandardCharsets.UTF_8);
            String inputtext;
            while ((inputtext = bufferedReader.readLine()) != null) {
                writer.write(inputtext);
                writer.newLine();
            }
            bufferedReader.close();
            writer.close();
            inputStreamReader.close();
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            if (result == true)
                logger.debug("download successfull - {}" , outfilename);
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                    logger.debug("error closing buffer reader - {} - {} - {}" , urlpath , outfolder , outfilename);
                }
            }
        }

        return result;
    }

    public boolean fileExists(String path , String filename) {
        boolean result = false;
        String filepath = path + "/" + filename;
        Path filenamepath = Paths.get(filepath);

        if (Files.exists(filenamepath)) {
            result = true;
            logger.debug("file already exists - {}" , filenamepath);
        }

        return result;
    }
}
