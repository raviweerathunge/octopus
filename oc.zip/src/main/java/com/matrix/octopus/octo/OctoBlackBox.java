package com.matrix.octopus.octo;

import com.matrix.octopus.Instrument;
import com.matrix.octopus.InstrumentLoader;
import com.matrix.octopus.RegistryEntry;

import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 11/10/2017.
 */
interface  OctoBlackBox {
    void init(RegistryEntry regentry, InstrumentLoader loader);
    void start();
    void process(ConcurrentHashMap<String, Instrument> filteredlist) throws OctoException;
    void stop();
    void cleanup();

    int getProgress();
    String getName();
    int getID();
    String getParentBox();
}
