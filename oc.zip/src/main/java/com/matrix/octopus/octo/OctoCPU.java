package com.matrix.octopus.octo;

import com.matrix.octopus.Instrument;
import com.matrix.octopus.InstrumentLoader;
import com.matrix.octopus.Registry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 11/10/2017.
 */
public class OctoCPU implements Runnable {
    private Registry octoregistry;
    private int cpuid = 0;
    private static Logger logger = LoggerFactory.getLogger(OctoCPU.class);


    public OctoCPU(int id , InstrumentLoader instrumentLoader , Registry registry) {
        this.octoregistry = registry;
        this.cpuid = id;
    }

    @Override
    public void run() {
        try {
            logger.debug("{} processing..", Thread.currentThread().getName());
            ArrayList<OctoBaseBox> bbarray = octoregistry.getBlackBoxForCpu(cpuid);
            int size = bbarray.size();
            String lastboxname = "";
            ConcurrentHashMap<String, Instrument> filteredlist = null;
            for(int i=0;i<size;i++) {
                OctoBaseBox bb = bbarray.get(i);
                if (bb != null) {
                    logger.debug("starting black box - {}",bb.getName());
                    bb.start();
                    String temp = bb.getParentBox();
                    if (temp.equals("") == false) {
                        if (temp.equals(lastboxname) == true) {
                            bb.process(filteredlist);
                        }
                    }
                    else {
                        bb.process(new ConcurrentHashMap<>());
                    }
                    bb.stop();
                    lastboxname = bb.getName();
                    filteredlist = bb.getFilteredinstruments();
                    logger.debug("completed black box - {}" , bb.getName());
                }
            }
            logger.debug("{} - completed" , Thread.currentThread().getName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
