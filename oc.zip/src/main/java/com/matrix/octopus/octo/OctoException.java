package com.matrix.octopus.octo;

public class OctoException extends  Exception {
    public OctoException(String message) {
        super(message);
    }
    public OctoException(String message, Exception inner) {
        super(message, inner);
    }

    public OctoException(Throwable cause) {
        super(cause);
    }
}
