package com.matrix.octopus.octo;

import com.matrix.octopus.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Created by raviw on 11/2/2017.
 */
@Component
public class Octopus implements CommandLineRunner {

    private InstrumentLoader instrumentLoader;
    private FileHandler filehandler;
    private FileParser fileparser;
    private Registry registry;

    public static OctoFactory octofactory = new OctoFactory();

    private boolean processing = true;
    ArrayList<Thread> threads = new ArrayList<Thread>();

    private static Logger logger = LoggerFactory.getLogger(Octopus.class);

    @Autowired
    public Octopus(InstrumentLoader loader , FileHandler handler , FileParser parser , Registry cpuRegister) {
        this.instrumentLoader = loader;
        this.filehandler = handler;
        this.fileparser = parser;
        this.registry = cpuRegister;
    }

    @Override
    public void run(String... args) throws Exception {
        startProcessing();
    }

    private boolean startProcessing() throws InterruptedException, IOException, SAXException {

        String line = "";
        Instrument instrument = null;

        String regfolder = OctoDefs.AFFINIT_FILE_PATH;
        boolean regload = registry.loadRegistryEntries(regfolder);
        if (regload == false) {
            logger.debug("error loading registry");
            return false;
        }

        fileparser.init();
        boolean insresult = instrumentLoader.loadInstrument(OctoDefs.INSTRUMENT_FILE_PATH);

        if (insresult == true)
        {
            ConcurrentHashMap<String, Instrument> instrumentlist = instrumentLoader.getInstruments();
            ArrayList<String> delistedinstruments = new ArrayList<>();
            for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet())  {
                line = entry.getKey();
                instrument = entry.getValue();
                logger.debug("reading instrunment - {}",line);

                boolean result = false;
                String folder = OctoDefs.FINANCIAL_OUT_FOLDER + OctoDefs.EXCHANGE_CODE + "/" + line;
                String bbfolder = OctoDefs.BLACK_BOX_OUT_FOLDER +  OctoDefs.EXCHANGE_CODE;
                File theDir = new File(folder);
                if (!theDir.exists()) {
                    logger.debug("creating directory: {}" , theDir.getName());
                    try {
                        theDir.mkdir();
                        result = true;
                    } catch (SecurityException se) {
                        logger.debug("error creating directory: {}",theDir.getName());
                    }
                } else {
                    result = true;
                }

                theDir = new File(bbfolder);
                if (!theDir.exists()) {
                    try {
                        theDir.mkdir();
                        logger.debug("creating blackbox directory: {}" , theDir.getName());
                    } catch (SecurityException se) {
                        logger.debug("error creating blackbox directory: {}" ,theDir.getName());
                    }
                }

                if (result == true){
                    ////
                    String urlpath = String.format("http://financials.morningstar.com/ajax/exportKR2CSV.html?t=%s:%s" , OctoDefs.EXCHANGE_CODE , line);
                    String filename = line + OctoDefs.RATIO_FILE_NAME_PREFIX;
                    if (!filehandler.fileExists(folder , filename) || OctoDefs.FILE_OVERWRITE == true)
                        filehandler.downloadFile(urlpath , folder , filename);

                    urlpath = String.format("http://financials.morningstar.com/ajax/ReportProcess4CSV.html?t=%s:%s&reportType=is&period=12&dataType=A&order=asc&columnYear=5&number=3", OctoDefs.EXCHANGE_CODE , line);
                    filename = line + OctoDefs.INCOME_STATEMENT_FILE_NAME_PREFIX;
                    if (!filehandler.fileExists(folder , filename) || OctoDefs.FILE_OVERWRITE == true)
                        filehandler.downloadFile(urlpath , folder , filename);

                    urlpath = String.format("http://financials.morningstar.com/ajax/ReportProcess4CSV.html?t=%s:%s&reportType=cf&period=12&dataType=A&order=asc&columnYear=5&number=3", OctoDefs.EXCHANGE_CODE , line);
                    filename = line +OctoDefs.CASH_FLOW_STATEMENT_FILE_NAME_PREFIX;
                    if (!filehandler.fileExists(folder , filename) || OctoDefs.FILE_OVERWRITE == true)
                        filehandler.downloadFile(urlpath , folder , filename);

                    urlpath = String.format("http://financials.morningstar.com/ajax/ReportProcess4CSV.html?t=%s:%s&reportType=bs&period=12&dataType=A&order=asc&columnYear=5&number=3", OctoDefs.EXCHANGE_CODE , line);
                    filename = line + OctoDefs.BALANCE_SHEET_STATEMENT_FILE_NAME_PREFIX;
                    if (!filehandler.fileExists(folder , filename) || OctoDefs.FILE_OVERWRITE == true)
                        filehandler.downloadFile(urlpath , folder , filename);

                    LocalDate date = LocalDate.now();
                    LocalDate olddate = date.minusYears(OctoDefs.OCTO_HISTORY_DATA_YEARS);

                    String to = date.toString();
                    String from = olddate.toString();

                    urlpath = String.format("https://www.investopedia.com/markets/api/partial/historical/?Symbol=%s.%s&Type=Historical+Prices&Timeframe=Daily&StartDate=%s+%d%%2C+%d&EndDate=%s+%d%%2C+%d" , line , OctoDefs.EXCHANGE_CODE , olddate.getMonth().getDisplayName(TextStyle.SHORT,Locale.ENGLISH) , olddate.getDayOfMonth() , olddate.getYear() , date.getMonth().getDisplayName(TextStyle.SHORT,Locale.ENGLISH) , date.getDayOfMonth() , date.getYear());
                    filename = line + OctoDefs.PRICE_FILE_NAME_PREFIX;
                    boolean downloaded = filehandler.fileExists(folder , filename);
                    if (!downloaded || OctoDefs.FILE_OVERWRITE == true) {
                        if (filehandler.downloadFile(urlpath, folder, filename)) {
                            downloaded = true;
                        }
                    }

                    if (downloaded) {
                        ArrayList<PriceInfo> pricelist = fileparser.parseInvestoPediaFile(folder, filename);
                        instrument.set_pricelist(pricelist);
                        logger.debug("price history array size - {}" ,String.valueOf(pricelist.size()));
                    }
                    else {
                        ArrayList<PriceInfo> pricelist = new ArrayList<>();
                        instrument.set_pricelist(pricelist);
                        delistedinstruments.add(line);
                    }
                }
                System.out.print("\n");
            }

            /// Remove delisted instruments
            int removecount = delistedinstruments.size();
            for(int i=0;i<removecount;i++) {
                String instrumentname = delistedinstruments.get(i);
                instrumentLoader.removeInstrument(instrumentname);

                // Remove instrument folder
                String folder = OctoDefs.FINANCIAL_OUT_FOLDER + OctoDefs.EXCHANGE_CODE + "/" + instrumentname;

                File file = new File(folder);
                OctoUtils.deleteDirectory(file);
            }

            instrumentLoader.writeValidInstruments(OctoDefs.INSTRUMENT_FILE_PATH);

            scanParameters();
            startCPUs();
        }
        else
            logger.debug("error reading file - " + OctoDefs.INSTRUMENT_FILE_PATH);

        return insresult;
    }

    private void scanParameters() {
        String line = "";
        Instrument inst = null;
        ConcurrentHashMap<String, Instrument> instrumentlist = instrumentLoader.getInstruments();
        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            line = entry.getKey();
            inst = entry.getValue();
            logger.debug("scanning instrument details - {}", line);
            String filename = line + OctoDefs.RATIO_FILE_NAME_PREFIX;
            String folder = OctoDefs.FINANCIAL_OUT_FOLDER + OctoDefs.EXCHANGE_CODE + "/" +  line;
            Parameters params = fileparser.parseratiofile(folder , filename);
            if (params != null) {
                inst.set_parameter(params);
            }
        }
    }

    private void startCPUs() throws InterruptedException {
        ExecutorService executor = Executors.newFixedThreadPool(OctoDefs.CPU_COUNT);

        for (int i=0 ; i < OctoDefs.CPU_COUNT ; i++) {
            executor.execute(new OctoCPU(i , instrumentLoader , registry));
        }

        executor.shutdown();
        executor.awaitTermination(Long.MAX_VALUE, TimeUnit.MINUTES);
        logger.debug("all cpus completed processing");
    }

}
