package com.matrix.octopus.octo;

/**
 * Created by raviw on 11/2/2017.
 */
public class OctoDefs {
    public static final String INSTRUMENT_FILE_PATH = "./configs/ASX300.csv";
    public static final String RATIO_FILE_NAME_PREFIX = "_KEY_RATIOS.csv";
    public static final String INCOME_STATEMENT_FILE_NAME_PREFIX = "_INCOME_STATEMENT.csv";
    public static final String CASH_FLOW_STATEMENT_FILE_NAME_PREFIX = "_CASH_FLOW_STATEMENT.csv";
    public static final String BALANCE_SHEET_STATEMENT_FILE_NAME_PREFIX = "_BALANCE_SHEET.csv";
    public static final String PRICE_FILE_NAME_PREFIX = "_PRICE_INFORMATION.log";
    public static final String FINANCIAL_OUT_FOLDER = "./financials/";
    public static final String AFFINIT_FILE_PATH = "./configs/affinity_single.xml";
    public static final String BLACK_BOX_OUT_FOLDER = "./blackbox/";
    public static final String EXCHANGE_CODE = "XASX";

    public static final boolean FILE_OVERWRITE = false;

    public static final int CPU_COUNT = 1;

    // Black boxes
    public static final String OCTO_BB_ROIC = "ROIC";
    public static final String OCTO_BB_DEBT_TO_EQUITY = "DEBTTOEQUITY";
    public static final String OCTO_BB_ROE = "ROE";
    public static final String OCTO_BB_QUICK_RATION = "QUICKRATIO";
    public static final String OCTO_BB_DIVIDEND_GROWTH = "DIVIDENDGROWTH";
    public static final String OCTO_BB_PE_SECTOR = "PESECTOR";
    public static final String OCTO_BB_PB = "PRICETOBOOK";
    public static final String OCTO_BB_STDDEVIATION = "STDDEVIATION";
    public static final String OCTO_BB_INTEREST_COVERAGE = "INTERESTCOVERAGE";
    public static final String OCTO_BB_PEXPB = "PExPB";
    public static final String OCTO_BB_GRAHAM = "GRAHAM";
    public static final String OCTO_BB_PE = "PE";
    public static final String OCTO_BB_PEG = "PEG";
    public static final String OCTO_BB_GROWTH_TO_EARNINGS = "GROWTHTOEARNINGS";
    public static final String OCTO_BB_CORRELATION = "CORRELATIONS";
    public static final String OCTO_BB_DUAL_MOMENTUM = "DUALMOMENTUM";

    public static final int OCTO_HISTORY_DATA_YEARS = 1;
    public static final int OCTO_DEFAULT_TAG_COUNT = 11;

    public static final Double OCTO_10_YEAR_AAA_BOND_RATE = 2.539;
    public static final Double OCTO_15_YEAR_AAA_BOND_RATE = 2.812;
    public static final Double OCTO_20_YEAR_AAA_BOND_RATE = 3.014;
    public static final Double OCTO_30_YEAR_AAA_BOND_RATE = 3.266;
}
