package com.matrix.octopus;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.ojalgo.series.CalendarDateSeries;
import org.ojalgo.type.CalendarDateUnit;
import org.ojalgo.type.Colour;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;

/**
 * Created by raviw on 11/2/2017.
 */
public class Instrument {
    public Semaphore mutex_parameter = new Semaphore(1);
    public Semaphore mutex_price = new Semaphore(1);

    private static Logger logger = LoggerFactory.getLogger(Instrument.class);

    public Instrument(String id , String name , String sector) {
        m_instrumentid = id;
        m_instrumentname = name;
        m_sector = sector;
    }
    public String get_instrumentname() {
        return m_instrumentid;
    }
    public String get_instrumentdescription(){return m_instrumentname; }

    public Parameters accquire_parameter() {
        try {
           mutex_parameter.acquire();
            return m_parameters;
        }
        catch (Exception e) {
            logger.debug("error accessing parameter for - {}" , m_instrumentid);
           return null;
        }
    }

    public void release_parameter() {
        mutex_parameter.release();
    }

    public void set_parameter(Parameters parameter) {
        try {
            mutex_parameter.acquire();
            this.m_parameters = parameter;
        }
        catch (Exception e) {
            logger.debug("error accessing parameter for - {}" , m_instrumentid);
        }
        finally {
            mutex_parameter.release();
        }
    }

    public void set_pricelist(ArrayList<PriceInfo> m_pricelist) {
        try {
            mutex_price.acquire();
            this.m_pricelist = m_pricelist;
        }
        catch (Exception e) {
            logger.debug("error accessing price info setting for - {}" , m_instrumentid);
        }
        finally {
            mutex_price.release();
        }
    }

    public PriceInfo getlatestpriceinfo() {
        PriceInfo pp = null;
        try {
            mutex_price.acquire();
            if (m_pricelist.size() > 0)
                pp = m_pricelist.get(0);
        }
        catch (Exception e) {
            logger.debug("error accessing price info for latest pricing - {}" , m_instrumentid);
        }
        finally {
            mutex_price.release();
        }
        return pp;
    }

    public PriceInfo getoldestpriceinfo() {
        PriceInfo pp = null;
        try {
            mutex_price.acquire();
            if (m_pricelist.size() > 0)
                pp = m_pricelist.get(m_pricelist.size() - 1);
        }
        catch (Exception e) {
            logger.debug("error accessing price info for latest pricing - {}" , m_instrumentid);
        }
        finally {
            mutex_price.release();
        }
        return pp;
    }

    public Double getMean() {
        DescriptiveStatistics stats = new DescriptiveStatistics();
        int size = m_pricelist.size();
        for (int i=0;i<size;i++) {
            stats.addValue(m_pricelist.get(i).getClose());
        }

        return stats.getMean();
    }

    public Double getStd() {
        DescriptiveStatistics stats = new DescriptiveStatistics();
        int size = m_pricelist.size();
        for (int i=0;i<size;i++) {
            stats.addValue(m_pricelist.get(i).getClose());
        }

        return stats.getStandardDeviation();
    }

    public String get_sector() {
        return m_sector;
    }

    public CalendarDateSeries<Double> getCalendarDateSeries() {
        CalendarDateSeries<Double> dateSeries = (CalendarDateSeries)((CalendarDateSeries)(new CalendarDateSeries(CalendarDateUnit.DAY)).name(this.m_instrumentid)).colour(Colour.random());

        int size = m_pricelist.size();
        for (int i=0;i<size;i++) {
            dateSeries.put(m_pricelist.get(i).getDate() , m_pricelist.get(i).getClose());
        }

        return dateSeries;
    }

    public Double getMktCap() {
        Parameters params = accquire_parameter();
        Parameter parameterCapital = params.getParameter("Shares Mil");

        if (parameterCapital == null || getlatestpriceinfo() == null)
            return 0.0;

        Double count = parameterCapital.getLatest();
        Double price = getlatestpriceinfo().getClose();

        release_parameter();

        return count * price;
    }

    private ArrayList<PriceInfo> m_pricelist;
    private Parameters m_parameters = null;
    private String m_instrumentid = "";
    private String m_instrumentname = "";
    private String m_sector = "";
}
