package com.matrix.octopus;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by raviw on 11/16/2017.
 */
public class PriceInfo {
    public Double getOpen() {
        return open;
    }

    public void setOpen(Double open) {
        this.open = open;
    }

    public Double getHigh() {
        return high;
    }

    public void setHigh(Double high) {
        this.high = high;
    }

    public Double getLow() {
        return low;
    }

    public void setLow(Double low) {
        this.low = low;
    }

    public Double getClose() {
        return close;
    }

    public void setClose(Double close) {
        this.close = close;
    }

    public void setPrice(int index , Double value) {
        if (index == 0)
            close = value;
        else if (index == 1)
            high = value;
        else if (index == 2)
            low = value;
        else if (index == 3)
            open = value;
    }

    public Double getVolume() {
        return volume;
    }

    public void setVolume(Double volume) {
        this.volume = volume;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(String value) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMMM d, yyyy" , Locale.ENGLISH);
        try {
            date = simpleDateFormat.parse(value);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private Double open = 0.0;
    private Double high = 0.0;
    private Double low = 0.0;
    private Double close = 0.0;
    private Double volume = 0.0;

    private Date date;

}
