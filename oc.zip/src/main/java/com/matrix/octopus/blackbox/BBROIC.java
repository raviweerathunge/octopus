package com.matrix.octopus.blackbox;

import com.matrix.octopus.Instrument;
import com.matrix.octopus.Parameter;
import com.matrix.octopus.Parameters;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;
import com.matrix.octopus.octo.OctoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 11/13/2017.
 */
public class BBROIC extends OctoBaseBox {

    private static Logger logger = LoggerFactory.getLogger(BBROIC.class);

    @Override
    public void process(ConcurrentHashMap<String, Instrument> filteredlist) throws OctoException {
        clearFilteredInstruments();

        ConcurrentHashMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameter = params.getParameter("Return on Invested Capital");
                if (parameter != null && parameter.getValidCount() > registryentry.getParameterValueInt(0) && parameter.getAverage() > registryentry.getParameterValueInt(1)) {
                    logger.debug("printing Return on Invested Capital history for " + instrument + " - is : " + parameter.getAverage());
                    writeblackboxfile("printing Return on Invested Capital history for " + instrument + " - is : " + parameter.getAverage());
                    addFilteredInstrument(instrument , instemp);
                }
            }
            instemp.release_parameter();
        }
    }
}
