package com.matrix.octopus.blackbox;

import com.matrix.octopus.*;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;
import com.matrix.octopus.octo.OctoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 11/22/2017.
 */
public class BBInterestCoverage extends OctoBaseBox {

    private static Logger logger = LoggerFactory.getLogger(BBInterestCoverage.class);

    @Override
    public void process(ConcurrentHashMap<String, Instrument> filteredlist) throws OctoException {
        clearFilteredInstruments();

        ConcurrentHashMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameter = params.getParameter("Interest Coverage");
                if (parameter != null && parameter.getValidCount() > registryentry.getParameterValueInt(0)) {
                    if (parameter.getAverage() > registryentry.getParameterValueDouble(1)) {
                        logger.debug("printing interest coverage history for " + instrument + " - is : " + parameter.getAverage());
                        writeblackboxfile("printing interest coverage history for " + instrument + " - is : " + parameter.getAverage());
                        addFilteredInstrument(instrument, instemp);
                    }
                    else {
                        logger.debug("filtering out " + instrument + " - is : " + parameter.getAverage());
                        writeblackboxfile("filtering out " + instrument + " - is : " + parameter.getAverage());
                    }
                }
            }
            instemp.release_parameter();
        }
    }
}
