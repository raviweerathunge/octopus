package com.matrix.octopus.blackbox;

import com.matrix.octopus.Instrument;
import com.matrix.octopus.Parameter;
import com.matrix.octopus.Parameters;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;
import com.matrix.octopus.octo.OctoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 11/15/2017.
 */
public class BBDebtToEquity extends OctoBaseBox {

    private static Logger logger = LoggerFactory.getLogger(BBDebtToEquity.class);


    @Override
    public void process(ConcurrentHashMap<String, Instrument> filteredlist) throws OctoException {
        clearFilteredInstruments();

        ConcurrentHashMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameter = params.getParameter("Debt/Equity");
                if (parameter != null && parameter.getLatest().isNaN() == false && parameter.getLatest() < registryentry.getParameterValueDouble(0)) {
                    logger.debug("printing Debt/Equity for {} - is : {}", instrument , parameter.getLatest());
                    writeblackboxfile("printing Debt/Equity history for " + instrument + " - is : " + parameter.getLatest());
                    addFilteredInstrument(instrument , instemp);
                }
            }
            instemp.release_parameter();
        }
    }
}
