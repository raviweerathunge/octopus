package com.matrix.octopus.blackbox;

import com.matrix.octopus.*;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;
import com.matrix.octopus.octo.OctoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 12/22/2017.
 */
public class BBGrowthToEarnings extends OctoBaseBox  {

    private static Logger logger = LoggerFactory.getLogger(BBGrowthToEarnings.class);

    @Override
    public void process(ConcurrentHashMap<String, Instrument> filteredlist) throws OctoException {
        clearFilteredInstruments();

        ConcurrentHashMap<String, Instrument> instrumentlist = null;
        if (filteredlist.size() == 0)
            instrumentlist = instrumentLoader.getInstruments();
        else
            instrumentlist = filteredlist;

        writeblackboxfile("INSTRUMENT" + "," + "DESCRIPTION" + "," + "GROWTH-TO_EARNINGS" + "," + "GROWTH" + "," + "DIVIDEND-GROWTH" + "," + "PE");

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameterEarnings = params.getParameter("Earnings Per Share");
                Parameter parameterDividends = params.getParameter("Dividends");

                if (parameterEarnings != null && parameterEarnings.getSize() > registryentry.getParameterValueInt(0)) {

                    int size = parameterEarnings.getSize();

                    Double last = parameterEarnings.getValue(registryentry.getParameterValueInt(1));
                    Double previous = parameterEarnings.getValue(registryentry.getParameterValueInt(2));

                    if (last.isNaN() == false && previous.isNaN() == false) {
                        PriceInfo priceInfo = instemp.getlatestpriceinfo();
                        if (priceInfo != null) {

                            Double peRatio = priceInfo.getClose() / last;
                            Double growth = ((last - previous) / previous) * 100;

                            Double dividendGrowth = 0.0;
                            if (parameterDividends != null && parameterDividends.getValidCount() > registryentry.getParameterValueInt(3) )
                                dividendGrowth = parameterDividends.getAverage();

                            if (dividendGrowth.isNaN() == false && dividendGrowth > registryentry.getParameterValueDouble(4) && growth > registryentry.getParameterValueDouble(5) && growth.isNaN() == false && peRatio.isNaN() == false && peRatio > registryentry.getParameterValueDouble(6)) {

                                Double growthtoearnings = (growth +  dividendGrowth) / peRatio;

                                if (growthtoearnings > registryentry.getParameterValueDouble(7) && growthtoearnings.isNaN() == false) {
                                    logger.debug("printing price / earnings history for " + instrument + " - is : " + peRatio);
                                    writeblackboxfile(instrument + "," + instemp.get_instrumentdescription() + "," + growthtoearnings + "," + growth + "," + dividendGrowth + "," + peRatio);
                                    addFilteredInstrument(instrument, instemp);
                                }
                            }
                        }
                    }
                 }
            }
            instemp.release_parameter();
        }
    }
}
