package com.matrix.octopus.blackbox;

import com.matrix.octopus.*;
import com.matrix.octopus.octo.OctoBaseBox;
import com.matrix.octopus.octo.OctoDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by raviw on 11/17/2017.
 */
public class BBPESector extends OctoBaseBox {

    private static Logger logger = LoggerFactory.getLogger(BBPESector.class);

    private SortedMap<String, Double> pesector = new TreeMap<>();
    private SortedMap<String, Integer>    pesectorcount = new TreeMap<>();

    public void process(ConcurrentHashMap<String, Instrument> filteredlist) {
        clearFilteredInstruments();

        ConcurrentHashMap<String, Instrument> instrumentlist = instrumentLoader.getInstruments();

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            Parameters params = instemp.accquire_parameter();
            if (params != null) {
                Parameter parameter = params.getParameter("Earnings Per Share");
                PriceInfo priceInfo = instemp.getlatestpriceinfo();

                if (priceInfo != null && parameter!= null && parameter.getValidCount() > 0 && parameter.getAverage() != 0 && parameter.getAverage().isNaN() == false) {
                    Double peRatio = priceInfo.getClose() / parameter.getAverage();
                    if (peRatio.isNaN() == false) {
                        addPEInfo(instemp.get_sector(), peRatio);
                    }
                }
            }
            instemp.release_parameter();
        }

        printSectorInfo();
    }

    public void addPEInfo(String sector , Double peRatio) {
        boolean result = pesector.containsKey(sector);
        if (result == false) {
            pesector.put(sector , peRatio);
            pesectorcount.put(sector , 1);
        }
        else {
            Double ratio = pesector.get(sector);
            ratio += peRatio;
            pesector.put(sector , ratio);

            int count = pesectorcount.get(sector);
            count++;
            pesectorcount.put(sector , count);
        }
    }

    public void printSectorInfo() {

        for (Map.Entry<String, Double> entry : pesector.entrySet()) {
            String sector = entry.getKey();
            Double value = entry.getValue();

            int count = pesectorcount.get(sector);

            if (count != 0) {
                Double average = value / count;
                logger.debug("sector average for sector - " + sector + " is: " + Double.toString(average));
                writeblackboxfile("printing sector average for sector - " + sector + " - is: " + Double.toString(average));
                printLessThanSector(sector , average);
                writeblackboxfile("----------------------------------------------------");
            }
            else {
                logger.debug("error calculating sector average for sector - " + sector);
            }
        }
    }

    public void printLessThanSector(String sector , Double value) {
        ConcurrentHashMap<String, Instrument> instrumentlist = instrumentLoader.getInstruments();

        for (Map.Entry<String, Instrument> entry : instrumentlist.entrySet()) {
            String instrument = entry.getKey();
            Instrument instemp = instrumentLoader.findInstrument(instrument);
            if (instemp.get_sector().equals(sector)) {
                Parameters params = instemp.accquire_parameter();
                if (params != null) {
                    Parameter parameter = params.getParameter("Earnings Per Share");
                    PriceInfo priceInfo = instemp.getlatestpriceinfo();

                    if (priceInfo != null && parameter != null && parameter.getAverage() != 0) {
                        Double peRatio = priceInfo.getClose() / parameter.getAverage();
                        if (value > 0) {
                            if (peRatio < value && peRatio >= 0) {
                                logger.debug("instrument - " + instrument + " has p/e ratio : " + Double.toString(peRatio));
                                writeblackboxfile("instrument - " + instrument + " has p/e ratio : " + Double.toString(peRatio));
                                addFilteredInstrument(instrument , instemp);
                            }
                        }
                        else {
                            if (peRatio > value) {
                                logger.debug("instrument - " + instrument + " has p/e ratio : " + Double.toString(peRatio));
                                writeblackboxfile("instrument - " + instrument + " has p/e ratio : " + Double.toString(peRatio));
                                addFilteredInstrument(instrument , instemp);
                            }
                        }
                    }

                    instemp.release_parameter();
                }
            }
        }
    }
}
