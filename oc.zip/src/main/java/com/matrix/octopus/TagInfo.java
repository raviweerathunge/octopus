package com.matrix.octopus;

/**
 * Created by raviw on 11/28/2017.
 */
public class TagInfo {
    public TagInfo(String name , int count) {
        m_name = name;
        m_count = count;
    }

    public String get_name() {
        return m_name;
    }

    public int get_count() {
        return m_count;
    }

    private String m_name = "";
    private int m_count = 0;
}
